import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";

type AuthContextValue = {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  signOut: () => Promise<void>;
  refreshAdmin: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const checkAdmin = async (uid: string | undefined) => {
    if (!uid) {
      setIsAdmin(false);
      return;
    }
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", uid)
      .eq("role", "admin")
      .maybeSingle();
    setIsAdmin(!!data);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      // defer admin check to avoid deadlock
      setTimeout(() => checkAdmin(s?.user?.id), 0);
    });

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      checkAdmin(s?.user?.id).finally(() => setLoading(false));
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  // Update online status on mount/unmount
  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").update({ status: "Online", last_seen: new Date().toISOString() }).eq("id", user.id).then(() => {});
    const handleUnload = () => {
      navigator.sendBeacon?.(
        `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/profiles?id=eq.${user.id}`,
      );
    };
    window.addEventListener("beforeunload", handleUnload);
    return () => {
      window.removeEventListener("beforeunload", handleUnload);
      supabase.from("profiles").update({ status: "Offline", last_seen: new Date().toISOString() }).eq("id", user.id).then(() => {});
    };
  }, [user]);

  const signOut = async () => {
    if (user) {
      await supabase.from("profiles").update({ status: "Offline" }).eq("id", user.id);
    }
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider
      value={{ user, session, loading, isAdmin, signOut, refreshAdmin: () => checkAdmin(user?.id) }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
}

// Helper: convert PK phone to email-shaped login id (for Supabase email auth)
export function phoneToEmail(phone: string) {
  const clean = phone.replace(/[^0-9]/g, "");
  return `${clean}@vxsquad.local`;
}

export function generatePlayerId() {
  return `VX-${Math.floor(100000 + Math.random() * 900000)}`;
}

// Validate Pakistani mobile number: 03XXXXXXXXX (11 digits) or +923XXXXXXXXX
export function validatePakPhone(raw: string): { valid: boolean; normalized: string } {
  const digits = raw.replace(/[^0-9]/g, "");
  // Accept 03XXXXXXXXX (11) or 923XXXXXXXXX (12) or 3XXXXXXXXX (10)
  let normalized = digits;
  if (digits.length === 10 && digits.startsWith("3")) normalized = "0" + digits;
  else if (digits.length === 12 && digits.startsWith("92")) normalized = "0" + digits.slice(2);
  else if (digits.length === 11 && digits.startsWith("03")) normalized = digits;
  else return { valid: false, normalized: digits };
  return { valid: /^03\d{9}$/.test(normalized), normalized };
}