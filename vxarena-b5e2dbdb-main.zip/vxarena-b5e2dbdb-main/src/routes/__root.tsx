import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Vx Arena — Find Your Free Fire Teammates" },
      { name: "description", content: "Vx Arena helps Free Fire players find perfect teammates. Match by role, skill & availability. Chat, build squads, win more." },
      { property: "og:title", content: "Vx Arena — Find Your Free Fire Teammates" },
      { property: "og:description", content: "Vx Arena helps Free Fire players find perfect teammates. Match by role, skill & availability. Chat, build squads, win more." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Vx Arena — Find Your Free Fire Teammates" },
      { name: "twitter:description", content: "Vx Arena helps Free Fire players find perfect teammates. Match by role, skill & availability. Chat, build squads, win more." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/5757c83a-ff32-4fe7-a0ca-2cbb25dd4d76/id-preview-deb6936f--bf4588b6-ffe5-458a-83b6-91e68cdb202c.lovable.app-1777431610917.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/5757c83a-ff32-4fe7-a0ca-2cbb25dd4d76/id-preview-deb6936f--bf4588b6-ffe5-458a-83b6-91e68cdb202c.lovable.app-1777431610917.png" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <Outlet />
      <Toaster richColors theme="dark" position="top-center" />
    </AuthProvider>
  );
}
