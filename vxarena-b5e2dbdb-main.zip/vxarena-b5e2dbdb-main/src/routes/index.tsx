import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { Trophy, Coins, Gem, Globe2, Gift, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VX Arena — Free Fire Tournaments & Cash Prizes" },
      { name: "description", content: "Join Free Fire tournaments, win coin prizes, exchange for diamonds. 1v1 to 50-player Booyah, Kill, and Survive matches." },
    ],
  }),
  component: Index,
});

function Index() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user) navigate({ to: "/matches" });
  }, [user, loading, navigate]);

  const features = [
    { icon: Trophy, title: "Daily Tournaments", desc: "1v1, 2v2, 3v3, 4v4 and 50-player Booyah lobbies. Booyah, Kill or Survive modes." },
    { icon: Coins, title: "Win Coin Prizes", desc: "Top 5 winners get 400 / 250 / 150 / 90 / 50 coins. Entry just 30 coins." },
    { icon: Gem, title: "Exchange for Diamonds", desc: "Convert 1500 coins into 100 diamonds and withdraw from 100 💎 onwards." },
    { icon: Globe2, title: "Region Locked", desc: "Fair matchmaking — every match is restricted to one region only." },
    { icon: Gift, title: "Daily Login Reward", desc: "7-day streak rewards — 5, 10, 15, 20, 25, 30, 50 coins. Free to claim." },
    { icon: ShieldCheck, title: "Safe Payouts", desc: "Verified Gmail + In-game UID withdrawals. Admin-reviewed for security." },
  ];

  return (
    <div className="min-h-screen">
      <header className="container mx-auto flex items-center justify-between p-4">
        <Logo size={36} withText />
        <div className="flex gap-2">
          <Link to="/login"><Button variant="ghost" size="sm">Login</Button></Link>
          <Link to="/signup"><Button size="sm" className="bg-primary text-primary-foreground">Sign Up</Button></Link>
        </div>
      </header>

      <section className="container mx-auto px-4 py-12 md:py-20 text-center">
        <div className="flex justify-center mb-6">
          <Logo size={96} />
        </div>
        <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-semibold mb-4">
          <Trophy className="h-3 w-3" /> Free Fire Tournament Platform
        </div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">
          Compete. Win. <span className="text-primary">Cash Out.</span>
        </h1>
        <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
          Join Free Fire tournaments, climb the ranks, and turn your wins into real diamonds. New players get <strong>100 coins free</strong>.
        </p>
        <div className="flex gap-3 justify-center flex-wrap">
          <Link to="/signup">
            <Button size="lg" className="bg-primary text-primary-foreground">Start Playing — Free 100 Coins</Button>
          </Link>
          <Link to="/login"><Button size="lg" variant="outline">Login</Button></Link>
        </div>
      </section>

      <section className="container mx-auto px-4 py-8 grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {features.map((f) => (
          <div key={f.title} className="soft-card rounded-xl p-5">
            <f.icon className="h-7 w-7 text-primary mb-3" />
            <h3 className="font-semibold mb-1">{f.title}</h3>
            <p className="text-sm text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </section>

      <section className="container mx-auto px-4 py-12">
        <div className="soft-card rounded-2xl p-6 md:p-10 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-2">Prize Pool Every Match</h2>
          <p className="text-muted-foreground mb-6">50-player Booyah tournaments distribute coins to the top 5 finishers.</p>
          <div className="grid grid-cols-5 gap-2 max-w-2xl mx-auto">
            {[
              { rank: "1st", prize: 400 },
              { rank: "2nd", prize: 250 },
              { rank: "3rd", prize: 150 },
              { rank: "4th", prize: 90 },
              { rank: "5th", prize: 50 },
            ].map((p) => (
              <div key={p.rank} className="rounded-lg bg-primary/5 p-3">
                <div className="text-xs text-muted-foreground">{p.rank}</div>
                <div className="font-bold text-primary">{p.prize}</div>
                <div className="text-[10px] text-muted-foreground">coins</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="container mx-auto p-6 text-center text-sm text-muted-foreground">
        © 2026 VX Arena — Free Fire Tournament Platform
      </footer>
    </div>
  );
}