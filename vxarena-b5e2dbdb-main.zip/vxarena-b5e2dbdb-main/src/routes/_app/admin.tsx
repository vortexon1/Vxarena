import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Plus, Trophy, Users, Trash2, Send, CheckCircle2, XCircle, Bell, Search, Ban, Copy } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Match = Database["public"]["Tables"]["matches"]["Row"];
type Mode = Database["public"]["Enums"]["match_mode"];
type MType = Database["public"]["Enums"]["match_type"];
type Region = Database["public"]["Enums"]["player_region"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];
type Entry = Database["public"]["Tables"]["match_entries"]["Row"];
type Withdrawal = Database["public"]["Tables"]["withdrawal_requests"]["Row"];
type WStatus = Database["public"]["Enums"]["withdrawal_status"];

const MODES: Mode[] = ["1v1", "2v2", "3v3", "4v4", "50p"];
const TYPES: MType[] = ["booyah", "kill", "survive"];
const REGIONS: Region[] = ["Pakistan", "India", "Bangladesh", "Indonesia", "Nepal", "Brazil", "Others"];
const MAX_BY_MODE: Record<Mode, number> = { "1v1": 2, "2v2": 4, "3v3": 6, "4v4": 8, "50p": 50 };
const DEFAULT_PRIZES = { p1: 400, p2: 250, p3: 150, p4: 90, p5: 50 };

export const Route = createFileRoute("/_app/admin")({
  head: () => ({ meta: [{ title: "Admin — VX Arena" }] }),
  component: AdminPage,
});

function AdminPage() {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [matches, setMatches] = useState<Match[]>([]);

  useEffect(() => {
    if (!loading && !isAdmin) navigate({ to: "/matches" });
  }, [isAdmin, loading, navigate]);

  const loadMatches = async () => {
    const { data } = await supabase.from("matches").select("*").order("scheduled_at", { ascending: false });
    setMatches(data ?? []);
  };
  useEffect(() => { if (isAdmin) loadMatches(); }, [isAdmin]);

  if (loading || !isAdmin) return <div className="text-center py-12">Loading...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Shield className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold">Admin Panel</h1>
      </div>

      <Tabs defaultValue="create">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="create"><Plus className="h-4 w-4 mr-1" /> Create Match</TabsTrigger>
          <TabsTrigger value="manage"><Trophy className="h-4 w-4 mr-1" /> Matches</TabsTrigger>
          <TabsTrigger value="players"><Users className="h-4 w-4 mr-1" /> Players</TabsTrigger>
          <TabsTrigger value="withdrawals"><Send className="h-4 w-4 mr-1" /> Payouts</TabsTrigger>
          <TabsTrigger value="notifs"><Bell className="h-4 w-4 mr-1" /> Notify</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="mt-4">
          <CreateMatchForm onCreated={loadMatches} />
        </TabsContent>

        <TabsContent value="manage" className="mt-4 space-y-3">
          {matches.length === 0 && <div className="text-center py-8 text-muted-foreground text-sm">No matches yet</div>}
          {matches.map((m) => <AdminMatchCard key={m.id} m={m} onChange={loadMatches} />)}
        </TabsContent>

        <TabsContent value="players" className="mt-4">
          <PlayersAdmin />
        </TabsContent>

        <TabsContent value="withdrawals" className="mt-4">
          <WithdrawalsAdmin />
        </TabsContent>

        <TabsContent value="notifs" className="mt-4">
          <NotificationsAdmin />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function CreateMatchForm({ onCreated }: { onCreated: () => void }) {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [mode, setMode] = useState<Mode>("50p");
  const [type, setType] = useState<MType>("booyah");
  const [region, setRegion] = useState<Region>("Pakistan");
  const [entryFee, setEntryFee] = useState(30);
  const [maxPlayers, setMaxPlayers] = useState(50);
  const [prizes, setPrizes] = useState(DEFAULT_PRIZES);
  const [scheduled, setScheduled] = useState(() => new Date(Date.now() + 60 * 60 * 1000).toISOString().slice(0, 16));
  const [busy, setBusy] = useState(false);

  useEffect(() => { setMaxPlayers(MAX_BY_MODE[mode]); }, [mode]);

  const submit = async () => {
    if (!user) return;
    if (!title.trim()) return toast.error("Title required");
    setBusy(true);
    const { error } = await supabase.from("matches").insert({
      title: title.trim(),
      mode, type,
      region,
      entry_fee: entryFee,
      max_players: maxPlayers,
      prize_1: prizes.p1, prize_2: prizes.p2, prize_3: prizes.p3, prize_4: prizes.p4, prize_5: prizes.p5,
      scheduled_at: new Date(scheduled).toISOString(),
      created_by: user.id,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Match created!");
    setTitle("");
    onCreated();
  };

  const totalPrize = prizes.p1 + prizes.p2 + prizes.p3 + prizes.p4 + prizes.p5;

  return (
    <div className="soft-card rounded-2xl p-5 space-y-3">
      <div>
        <Label>Title</Label>
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Sunday Night Booyah" />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label>Mode</Label>
          <Select value={mode} onValueChange={(v) => setMode(v as Mode)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{MODES.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label>Type</Label>
          <Select value={type} onValueChange={(v) => setType(v as MType)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{TYPES.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label>Region * (locked to this region only)</Label>
          <Select value={region} onValueChange={(v) => setRegion(v as Region)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {REGIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Schedule</Label>
          <Input type="datetime-local" value={scheduled} onChange={(e) => setScheduled(e.target.value)} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label>Entry fee (coins)</Label>
          <Input type="number" min={0} value={entryFee} onChange={(e) => setEntryFee(parseInt(e.target.value) || 0)} />
        </div>
        <div>
          <Label>Max players</Label>
          <Input type="number" min={2} value={maxPlayers} onChange={(e) => setMaxPlayers(parseInt(e.target.value) || 2)} />
        </div>
      </div>
      <div>
        <Label>Prize pool ({totalPrize} coins total)</Label>
        <div className="grid grid-cols-5 gap-1.5">
          {(["p1", "p2", "p3", "p4", "p5"] as const).map((k, i) => (
            <div key={k}>
              <div className="text-[10px] text-center text-muted-foreground">{i + 1}{["st", "nd", "rd", "th", "th"][i]}</div>
              <Input type="number" min={0} value={prizes[k]} onChange={(e) => setPrizes({ ...prizes, [k]: parseInt(e.target.value) || 0 })} />
            </div>
          ))}
        </div>
      </div>
      <Button onClick={submit} disabled={busy} className="w-full bg-primary text-primary-foreground">
        {busy ? "Creating..." : "Create Match"}
      </Button>
    </div>
  );
}

function AdminMatchCard({ m, onChange }: { m: Match; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [entries, setEntries] = useState<(Entry & { profile?: Profile })[]>([]);
  const [ranks, setRanks] = useState<Record<string, number>>({});
  const [roomId, setRoomId] = useState(m.room_id_text ?? "");
  const [roomPass, setRoomPass] = useState(m.room_password ?? "");
  const [busy, setBusy] = useState(false);

  const loadEntries = async () => {
    const { data: es } = await supabase.from("match_entries").select("*").eq("match_id", m.id);
    const ids = (es ?? []).map((e) => e.user_id);
    const { data: ps } = ids.length ? await supabase.from("profiles").select("*").in("id", ids) : { data: [] };
    const map = new Map((ps ?? []).map((p) => [p.id, p]));
    setEntries((es ?? []).map((e) => ({ ...e, profile: map.get(e.user_id) })));
    const r: Record<string, number> = {};
    (es ?? []).forEach((e) => { if (e.rank) r[e.user_id] = e.rank; });
    setRanks(r);
  };
  useEffect(() => { if (open) loadEntries(); }, [open, m.id]);

  const saveRoom = async () => {
    setBusy(true);
    const { error } = await supabase.from("matches").update({
      room_id_text: roomId || null,
      room_password: roomPass || null,
      status: roomId ? "live" : m.status,
    }).eq("id", m.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Room info saved");
    onChange();
  };

  const submitRanks = async () => {
    const list = Object.entries(ranks).filter(([, r]) => r >= 1 && r <= 5).map(([user_id, rank]) => ({ user_id, rank }));
    if (list.length === 0) return toast.error("Set at least one rank (1-5)");
    setBusy(true);
    const { error } = await supabase.rpc("set_match_ranks", { _match_id: m.id, _ranks: list });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Prizes distributed!");
    onChange();
    loadEntries();
  };

  const remove = async () => {
    if (!confirm("Delete match? Entries will also be deleted.")) return;
    const { error } = await supabase.from("matches").delete().eq("id", m.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    onChange();
  };

  return (
    <div className="soft-card rounded-xl p-3">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between gap-2 text-left">
        <div className="min-w-0">
          <div className="font-semibold truncate">{m.title}</div>
          <div className="text-[11px] text-muted-foreground">{m.mode} • {m.type} • {m.status} • {new Date(m.scheduled_at).toLocaleString()}</div>
        </div>
        <Users className="h-4 w-4 text-muted-foreground flex-shrink-0" />
      </button>

      {open && (
        <div className="mt-3 space-y-3 pt-3 border-t border-border">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-xs">Room ID</Label>
              <Input value={roomId} onChange={(e) => setRoomId(e.target.value)} placeholder="123456" />
            </div>
            <div>
              <Label className="text-xs">Room password</Label>
              <Input value={roomPass} onChange={(e) => setRoomPass(e.target.value)} placeholder="abc" />
            </div>
          </div>
          <Button size="sm" onClick={saveRoom} disabled={busy} variant="outline" className="w-full">Save room info & set live</Button>

          <div>
            <Label className="text-xs">Players ({entries.length}/{m.max_players}) — set ranks 1-5 to distribute prizes</Label>
            <div className="space-y-1.5 mt-1 max-h-64 overflow-auto">
              {entries.length === 0 && <div className="text-xs text-muted-foreground py-2">No players joined</div>}
              {entries.map((e) => (
                <div key={e.id} className="flex items-center gap-2 text-sm">
                  <span className="flex-1 truncate">{e.profile?.ingame_name ?? "?"} <span className="text-muted-foreground text-[11px]">({e.profile?.ingame_uid ?? "—"})</span></span>
                  {e.rank && e.prize_coins > 0 && <span className="text-[11px] text-success">+{e.prize_coins}</span>}
                  <Input
                    type="number"
                    min={0}
                    max={5}
                    value={ranks[e.user_id] ?? ""}
                    onChange={(ev) => setRanks({ ...ranks, [e.user_id]: parseInt(ev.target.value) || 0 })}
                    placeholder="rank"
                    className="w-20 h-8"
                  />
                </div>
              ))}
            </div>
          </div>
          {entries.length > 0 && m.status !== "completed" && (
            <Button size="sm" onClick={submitRanks} disabled={busy} className="w-full bg-primary text-primary-foreground">
              <Trophy className="h-3 w-3 mr-1" /> Submit ranks & distribute prizes
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={remove} className="w-full text-destructive border-destructive/30">
            <Trash2 className="h-3 w-3 mr-1" /> Delete match
          </Button>
        </div>
      )}
    </div>
  );
}

function WithdrawalsAdmin() {
  const [items, setItems] = useState<(Withdrawal & { profile?: Profile })[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});

  const load = async () => {
    const { data } = await supabase.from("withdrawal_requests").select("*").order("created_at", { ascending: false });
    const ids = (data ?? []).map((r) => r.user_id);
    const { data: ps } = ids.length ? await supabase.from("profiles").select("*").in("id", ids) : { data: [] };
    const map = new Map((ps ?? []).map((p) => [p.id, p]));
    setItems((data ?? []).map((r) => ({ ...r, profile: map.get(r.user_id) })));
  };
  useEffect(() => { load(); }, []);

  useEffect(() => {
    const ch = supabase.channel("admin-wd")
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawal_requests" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const act = async (id: string, status: WStatus) => {
    setBusy(id);
    const { error } = await supabase.rpc("set_withdrawal_status", { _request_id: id, _status: status, _note: notes[id] || undefined });
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Updated");
    load();
  };

  const pending = items.filter((i) => i.status === "pending");
  const processed = items.filter((i) => i.status !== "pending");

  return (
    <div className="space-y-3">
      <div>
        <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-2">Pending ({pending.length})</h2>
        {pending.length === 0 && <div className="text-center py-6 text-sm text-muted-foreground">No pending requests</div>}
        {pending.map((r) => (
          <div key={r.id} className="soft-card rounded-xl p-3 space-y-2 mb-2">
            <div className="flex items-center justify-between">
              <div className="font-bold">{r.diamonds} 💎</div>
              <div className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString()}</div>
            </div>
            <div className="text-sm">{r.profile?.ingame_name ?? "Player"} — {r.profile?.region ?? "?"}</div>
            <div className="text-xs text-muted-foreground">Gmail: <strong>{r.gmail}</strong></div>
            <div className="text-xs text-muted-foreground">In-game UID: <strong>{r.ingame_uid}</strong></div>
            <Input
              placeholder="Optional note (visible to player)"
              value={notes[r.id] ?? ""}
              onChange={(e) => setNotes({ ...notes, [r.id]: e.target.value })}
              className="h-8 text-xs"
            />
            <div className="grid grid-cols-3 gap-2">
              <Button size="sm" disabled={busy === r.id} onClick={() => act(r.id, "approved")} variant="outline">
                <CheckCircle2 className="h-3 w-3 mr-1" /> Approve
              </Button>
              <Button size="sm" disabled={busy === r.id} onClick={() => act(r.id, "paid")} className="bg-success text-white">
                <Send className="h-3 w-3 mr-1" /> Mark Paid
              </Button>
              <Button size="sm" disabled={busy === r.id} onClick={() => act(r.id, "rejected")} variant="outline" className="text-destructive border-destructive/40">
                <XCircle className="h-3 w-3 mr-1" /> Reject
              </Button>
            </div>
          </div>
        ))}
      </div>

      {processed.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-2">Processed</h2>
          {processed.map((r) => (
            <div key={r.id} className="soft-card rounded-xl p-3 mb-2 text-sm flex items-center justify-between">
              <div className="min-w-0">
                <div className="font-medium truncate">{r.profile?.ingame_name ?? "Player"} — {r.diamonds} 💎</div>
                <div className="text-[11px] text-muted-foreground">{r.gmail} • {new Date(r.created_at).toLocaleDateString()}</div>
              </div>
              <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-muted">{r.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PlayersAdmin() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [search, setSearch] = useState("");
  const [region, setRegion] = useState<string>("all");
  const [busy, setBusy] = useState<string | null>(null);
  const [notifyTarget, setNotifyTarget] = useState<Profile | null>(null);
  const [notifyTitle, setNotifyTitle] = useState("");
  const [notifyBody, setNotifyBody] = useState("");
  const [notifyKind, setNotifyKind] = useState("warning");

  const load = async () => {
    const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(500);
    setProfiles(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const filtered = profiles.filter((p) => {
    if (region !== "all" && p.region !== region) return false;
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      p.ingame_name?.toLowerCase().includes(q) ||
      p.ingame_uid?.toLowerCase().includes(q) ||
      p.player_id?.toLowerCase().includes(q) ||
      p.phone?.toLowerCase().includes(q)
    );
  });

  const toggleBan = async (p: Profile) => {
    if (!confirm(`${p.is_banned ? "Unban" : "Ban"} ${p.ingame_name}?`)) return;
    setBusy(p.id);
    const { error } = await supabase.from("profiles").update({ is_banned: !p.is_banned }).eq("id", p.id);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success(p.is_banned ? "Unbanned" : "Banned");
    load();
  };

  const sendNotify = async () => {
    if (!notifyTarget) return;
    if (!notifyTitle.trim() || !notifyBody.trim()) return toast.error("Title and message required");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from("notifications").insert({
      title: notifyTitle.trim(),
      body: notifyBody.trim(),
      kind: notifyKind,
      target_user_id: notifyTarget.id,
      is_broadcast: false,
      created_by: user.id,
    });
    if (error) return toast.error(error.message);
    toast.success("Notification sent");
    setNotifyTarget(null); setNotifyTitle(""); setNotifyBody("");
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Search name, UID, player ID, phone…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Select value={region} onValueChange={setRegion}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All regions</SelectItem>
            {REGIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="text-xs text-muted-foreground">{filtered.length} player(s)</div>

      <div className="space-y-2">
        {filtered.map((p) => (
          <div key={p.id} className={`soft-card rounded-xl p-3 ${p.is_banned ? "border border-destructive/40" : ""}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="font-semibold truncate flex items-center gap-2">
                  {p.ingame_name}
                  {p.is_banned && <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-destructive text-destructive-foreground">BANNED</span>}
                </div>
                <div className="text-[11px] text-muted-foreground space-y-0.5 mt-1">
                  <div className="flex items-center gap-1">
                    <span>ID: <strong className="text-foreground">{p.player_id}</strong></span>
                    <button onClick={() => { navigator.clipboard.writeText(p.player_id); toast.success("Copied"); }}>
                      <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <div>UID: {p.ingame_uid ?? "—"} • {p.region ?? "—"}</div>
                  <div>Phone: {p.phone ?? "—"} • {p.role} • {p.status}</div>
                  <div>Joined: {new Date(p.created_at).toLocaleDateString()}</div>
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <Button size="sm" variant="outline" onClick={() => setNotifyTarget(p)}>
                  <Bell className="h-3 w-3 mr-1" /> Notify
                </Button>
                <Button size="sm" variant="outline" disabled={busy === p.id} onClick={() => toggleBan(p)} className={p.is_banned ? "text-success border-success/40" : "text-destructive border-destructive/40"}>
                  <Ban className="h-3 w-3 mr-1" /> {p.is_banned ? "Unban" : "Ban"}
                </Button>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div className="text-center py-8 text-sm text-muted-foreground">No players found</div>}
      </div>

      {notifyTarget && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setNotifyTarget(null)}>
          <div className="bg-card rounded-2xl p-5 w-full max-w-md space-y-3" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-bold">Send notification to {notifyTarget.ingame_name}</h3>
            <div>
              <Label className="text-xs">Type</Label>
              <Select value={notifyKind} onValueChange={setNotifyKind}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="ban">Ban notice</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Input placeholder="Title" value={notifyTitle} onChange={(e) => setNotifyTitle(e.target.value)} />
            <Textarea placeholder="Message…" rows={4} value={notifyBody} onChange={(e) => setNotifyBody(e.target.value)} />
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setNotifyTarget(null)}>Cancel</Button>
              <Button className="flex-1 bg-primary text-primary-foreground" onClick={sendNotify}>Send</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

type Notif = { id: string; title: string; body: string; kind: string; is_broadcast: boolean; target_user_id: string | null; created_at: string };

function NotificationsAdmin() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [kind, setKind] = useState("info");
  const [busy, setBusy] = useState(false);
  const [items, setItems] = useState<Notif[]>([]);

  const load = async () => {
    const { data } = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(50);
    setItems((data ?? []) as Notif[]);
  };
  useEffect(() => { load(); }, []);

  const broadcast = async () => {
    if (!title.trim() || !body.trim()) return toast.error("Title and message required");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("notifications").insert({
      title: title.trim(), body: body.trim(), kind, is_broadcast: true, created_by: user.id,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Sent to all players");
    setTitle(""); setBody("");
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this notification?")) return;
    const { error } = await supabase.from("notifications").delete().eq("id", id);
    if (error) return toast.error(error.message);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="soft-card rounded-2xl p-5 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><Bell className="h-4 w-4 text-primary" /> Broadcast to all players</h2>
        <div>
          <Label className="text-xs">Type</Label>
          <Select value={kind} onValueChange={setKind}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="info">Info / Update</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="ban">Important</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Input placeholder="Title (e.g. New tournament tomorrow!)" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Textarea placeholder="Message details…" rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
        <Button onClick={broadcast} disabled={busy} className="w-full bg-primary text-primary-foreground">
          {busy ? "Sending..." : "Send to All Players"}
        </Button>
      </div>

      <div>
        <h3 className="text-sm font-semibold uppercase text-muted-foreground mb-2">Recent ({items.length})</h3>
        {items.map((n) => (
          <div key={n.id} className="soft-card rounded-xl p-3 mb-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="font-semibold flex items-center gap-2">
                  {n.title}
                  <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-muted">{n.is_broadcast ? "All" : "Targeted"}</span>
                  <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary">{n.kind}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{n.body}</p>
                <div className="text-[10px] text-muted-foreground mt-1">{new Date(n.created_at).toLocaleString()}</div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => remove(n.id)} className="text-destructive">
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          </div>
        ))}
        {items.length === 0 && <div className="text-center py-6 text-sm text-muted-foreground">No notifications yet</div>}
      </div>
    </div>
  );
}