import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Gem, Send, Clock, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

type Wallet = Database["public"]["Tables"]["wallets"]["Row"];
type Req = Database["public"]["Tables"]["withdrawal_requests"]["Row"];

const MIN_WITHDRAW = 100;

const schema = z.object({
  diamonds: z.number().int().min(MIN_WITHDRAW, `Minimum ${MIN_WITHDRAW} diamonds`),
  gmail: z.string().trim().email("Valid Gmail required").max(255),
  ingame_uid: z.string().trim().min(4, "In-game UID required").max(20),
});

export const Route = createFileRoute("/_app/withdraw")({
  head: () => ({ meta: [{ title: "Withdraw — VX Arena" }] }),
  component: WithdrawPage,
});

function WithdrawPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [requests, setRequests] = useState<Req[]>([]);
  const [diamonds, setDiamonds] = useState<number>(MIN_WITHDRAW);
  const [gmail, setGmail] = useState("");
  const [uid, setUid] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!user) return;
    const { data: w } = await supabase.from("wallets").select("*").eq("user_id", user.id).maybeSingle();
    setWallet(w);
    const { data: r } = await supabase.from("withdrawal_requests").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
    setRequests(r ?? []);
  };

  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [user]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase.channel("withdraw-" + user.id)
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawal_requests", filter: `user_id=eq.${user.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ diamonds, gmail, ingame_uid: uid });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    if (!wallet || wallet.diamonds < diamonds) return toast.error("Insufficient diamonds");
    setBusy(true);
    const { error } = await supabase.rpc("submit_withdrawal", {
      _diamonds: parsed.data.diamonds,
      _gmail: parsed.data.gmail,
      _ingame_uid: parsed.data.ingame_uid,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Withdrawal request submitted! Admin will process soon.");
    setGmail(""); setUid(""); setDiamonds(MIN_WITHDRAW);
    load();
  };

  const balance = wallet?.diamonds ?? 0;
  const canWithdraw = balance >= MIN_WITHDRAW;

  return (
    <div className="space-y-4 max-w-2xl">
      <button onClick={() => navigate({ to: "/wallet" })} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to wallet
      </button>

      <div className="soft-card rounded-2xl p-5 bg-gradient-to-br from-primary/10 to-transparent">
        <div className="flex items-center gap-2">
          <Gem className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Withdraw Diamonds</h1>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Minimum withdrawal: <strong>{MIN_WITHDRAW} diamonds</strong>. Diamonds will be held until admin processes your request.
        </p>
        <div className="mt-3 text-sm">
          Your balance: <strong className="text-primary">{balance} 💎</strong>
        </div>
      </div>

      {!canWithdraw ? (
        <div className="soft-card rounded-2xl p-5 text-center text-sm text-muted-foreground">
          You need at least <strong>{MIN_WITHDRAW} diamonds</strong> to request a withdrawal.
          You have <strong>{balance}</strong> — earn more by winning matches!
        </div>
      ) : (
        <form onSubmit={submit} className="soft-card rounded-2xl p-5 space-y-3">
          <h2 className="font-bold">Request withdrawal</h2>
          <div>
            <Label htmlFor="dia">Diamonds amount *</Label>
            <Input
              id="dia"
              type="number"
              min={MIN_WITHDRAW}
              max={balance}
              value={diamonds}
              onChange={(e) => setDiamonds(parseInt(e.target.value) || 0)}
              required
            />
          </div>
          <div>
            <Label htmlFor="gmail">Your Gmail *</Label>
            <Input
              id="gmail"
              type="email"
              placeholder="you@gmail.com"
              value={gmail}
              onChange={(e) => setGmail(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="uid">Free Fire in-game UID *</Label>
            <Input
              id="uid"
              placeholder="e.g. 1234567890"
              value={uid}
              onChange={(e) => setUid(e.target.value)}
              required
            />
          </div>
          <Button type="submit" disabled={busy} className="w-full bg-primary text-primary-foreground">
            <Send className="h-4 w-4 mr-1" />
            {busy ? "Submitting..." : `Submit — ${diamonds} 💎`}
          </Button>
        </form>
      )}

      <div className="soft-card rounded-2xl p-5">
        <h2 className="font-bold mb-3">Your requests</h2>
        {requests.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-3">No withdrawal requests yet.</p>
        ) : (
          <div className="space-y-2">
            {requests.map((r) => (
              <div key={r.id} className="rounded-lg bg-muted/40 p-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-bold inline-flex items-center gap-1"><Gem className="h-3.5 w-3.5 text-primary" />{r.diamonds}</span>
                  <StatusBadge status={r.status} />
                </div>
                <div className="text-xs text-muted-foreground mt-1">{new Date(r.created_at).toLocaleString()}</div>
                <div className="text-[11px] text-muted-foreground mt-1">{r.gmail} • UID {r.ingame_uid}</div>
                {r.admin_note && <div className="text-[11px] mt-1 italic">Note: {r.admin_note}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Req["status"] }) {
  const map = {
    pending: { cls: "bg-warning/15 text-warning", icon: Clock },
    approved: { cls: "bg-primary/15 text-primary", icon: CheckCircle2 },
    paid: { cls: "bg-success/15 text-success", icon: CheckCircle2 },
    rejected: { cls: "bg-destructive/15 text-destructive", icon: XCircle },
  } as const;
  const { cls, icon: Icon } = map[status];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${cls}`}>
      <Icon className="h-3 w-3" /> {status}
    </span>
  );
}