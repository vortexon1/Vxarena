import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Copy, Upload } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];
type Region = Database["public"]["Enums"]["player_region"];
type Role = Database["public"]["Enums"]["player_role"];
const REGIONS: Region[] = ["Pakistan", "India", "Bangladesh", "Indonesia", "Nepal", "Brazil", "Others"];
const ROLES: Role[] = ["Rusher", "Sniper", "Support"];

export const Route = createFileRoute("/_app/profile")({
  head: () => ({ meta: [{ title: "My Profile — VX Arena" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = useAuth();
  const [p, setP] = useState<Profile | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => setP(data));
  }, [user]);

  const save = async () => {
    if (!p || !user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({
      ingame_name: p.ingame_name,
      ingame_uid: p.ingame_uid,
      role: p.role,
      region: p.region,
      bio: p.bio,
    }).eq("id", user.id);
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success("Profile updated!");
  };

  const replaceScreenshot = async (file: File) => {
    if (!user) return;
    if (file.size > 5 * 1024 * 1024) return toast.error("Max 5MB");
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${user.id}/ff-profile-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("ff-screenshots").upload(path, file, { upsert: true });
    if (error) return toast.error(error.message);
    const { data: pub } = supabase.storage.from("ff-screenshots").getPublicUrl(path);
    await supabase.from("profiles").update({ ff_screenshot_url: pub.publicUrl }).eq("id", user.id);
    setP({ ...p!, ff_screenshot_url: pub.publicUrl });
    toast.success("Screenshot updated!");
  };

  if (!p) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="soft-card rounded-2xl p-5 text-center">
        {p.ff_screenshot_url ? (
          <img src={p.ff_screenshot_url} alt="FF profile" className="w-full max-h-72 object-contain rounded-xl mb-3 bg-muted" />
        ) : (
          <div className="h-20 w-20 mx-auto rounded-full bg-primary/15 text-primary flex items-center justify-center text-3xl font-black">
            {p.ingame_name.charAt(0).toUpperCase()}
          </div>
        )}
        <h1 className="text-2xl font-bold mt-2">{p.ingame_name}</h1>
        <button
          onClick={() => { navigator.clipboard.writeText(p.player_id); toast.success("Player ID copied!"); }}
          className="inline-flex items-center gap-1.5 text-xs font-mono text-muted-foreground mt-1 hover:text-primary"
        >
          {p.player_id} <Copy className="h-3 w-3" />
        </button>
        <label className="block mt-3">
          <span className="inline-flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg border border-border cursor-pointer hover:bg-muted">
            <Upload className="h-3 w-3" /> Replace screenshot
          </span>
          <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) replaceScreenshot(f); }} />
        </label>
      </div>

      <div className="soft-card rounded-2xl p-5 space-y-3">
        <h2 className="font-bold text-lg">Edit profile</h2>
        <div>
          <Label>In-game name</Label>
          <Input value={p.ingame_name} onChange={(e) => setP({ ...p, ingame_name: e.target.value })} />
        </div>
        <div>
          <Label>FF UID</Label>
          <Input value={p.ingame_uid ?? ""} onChange={(e) => setP({ ...p, ingame_uid: e.target.value })} />
        </div>
        <div>
          <Label>Bio</Label>
          <Textarea value={p.bio ?? ""} onChange={(e) => setP({ ...p, bio: e.target.value })} maxLength={200} />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label>Region</Label>
            <Select value={p.region ?? undefined} onValueChange={(v) => setP({ ...p, region: v as Region })}>
              <SelectTrigger><SelectValue placeholder="Select region" /></SelectTrigger>
              <SelectContent>
                {REGIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Role</Label>
            <Select value={p.role} onValueChange={(v) => setP({ ...p, role: v as Role })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button onClick={save} disabled={saving} className="w-full bg-primary text-primary-foreground">
          {saving ? "Saving..." : "Save changes"}
        </Button>
      </div>
    </div>
  );
}