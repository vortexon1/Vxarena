import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Bell, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Notif = {
  id: string;
  title: string;
  body: string;
  kind: string;
  is_broadcast: boolean;
  target_user_id: string | null;
  created_at: string;
};

export const Route = createFileRoute("/_app/notifications")({
  head: () => ({ meta: [{ title: "Notifications — VX Arena" }] }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Notif[]>([]);
  const [reads, setReads] = useState<Set<string>>(new Set());

  const load = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .or(`is_broadcast.eq.true,target_user_id.eq.${user.id}`)
      .order("created_at", { ascending: false })
      .limit(100);
    setItems((data ?? []) as Notif[]);
    const { data: r } = await supabase
      .from("notification_reads")
      .select("notification_id")
      .eq("user_id", user.id);
    setReads(new Set((r ?? []).map((x) => x.notification_id)));
  };

  useEffect(() => { load(); }, [user]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel("notifs")
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const markAllRead = async () => {
    if (!user) return;
    const unread = items.filter((i) => !reads.has(i.id));
    if (unread.length === 0) return;
    await supabase.from("notification_reads").upsert(
      unread.map((i) => ({ user_id: user.id, notification_id: i.id })),
      { onConflict: "user_id,notification_id" },
    );
    toast.success("Marked all as read");
    load();
  };

  const kindColor = (k: string) =>
    k === "warning" ? "border-warning/40 bg-warning/5"
    : k === "ban" ? "border-destructive/40 bg-destructive/5"
    : "border-border bg-card";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-bold">Notifications</h1>
        </div>
        <Button size="sm" variant="outline" onClick={markAllRead}>
          <CheckCheck className="h-3 w-3 mr-1" /> Mark all read
        </Button>
      </div>

      {items.length === 0 && (
        <div className="text-center py-12 text-sm text-muted-foreground">No notifications yet</div>
      )}
      {items.map((n) => {
        const unread = !reads.has(n.id);
        return (
          <div key={n.id} className={`rounded-xl p-4 border ${kindColor(n.kind)} ${unread ? "ring-1 ring-primary/30" : ""}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="font-semibold">{n.title}</div>
              {!n.is_broadcast && <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary">Personal</span>}
              {n.is_broadcast && <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-muted">Announcement</span>}
            </div>
            <p className="text-sm text-muted-foreground mt-1 whitespace-pre-wrap">{n.body}</p>
            <div className="text-[11px] text-muted-foreground mt-2">{new Date(n.created_at).toLocaleString()}</div>
          </div>
        );
      })}
    </div>
  );
}