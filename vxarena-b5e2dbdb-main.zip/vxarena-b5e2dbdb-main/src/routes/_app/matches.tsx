import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Trophy, Users, Coins, Clock, ChevronRight, MapPin } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type Match = Database["public"]["Tables"]["matches"]["Row"];
type Entry = Database["public"]["Tables"]["match_entries"]["Row"];

export const Route = createFileRoute("/_app/matches")({
  head: () => ({ meta: [{ title: "Matches — VX Arena" }] }),
  component: MatchesPage,
});

function MatchesPage() {
  const { user } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});

  const load = async () => {
    const { data: m } = await supabase.from("matches").select("*").order("scheduled_at", { ascending: true });
    setMatches(m ?? []);
    if (user) {
      const { data: e } = await supabase.from("match_entries").select("*").eq("user_id", user.id);
      setEntries(e ?? []);
    }
    const ids = (m ?? []).map((x) => x.id);
    if (ids.length) {
      const { data: all } = await supabase.from("match_entries").select("match_id").in("match_id", ids);
      const c: Record<string, number> = {};
      (all ?? []).forEach((r) => { c[r.match_id] = (c[r.match_id] ?? 0) + 1; });
      setCounts(c);
    }
  };

  useEffect(() => { load(); }, [user]);

  useEffect(() => {
    const ch = supabase.channel("matches-feed")
      .on("postgres_changes", { event: "*", schema: "public", table: "matches" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "match_entries" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const joinedSet = new Set(entries.map((e) => e.match_id));
  const upcoming = matches.filter((m) => m.status === "upcoming" || m.status === "live");
  const past = matches.filter((m) => m.status === "completed");

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Trophy className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold">Tournaments</h1>
      </div>

      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Upcoming & Live</h2>
        {upcoming.length === 0 && (
          <div className="soft-card rounded-xl p-8 text-center text-muted-foreground text-sm">
            No matches available right now. Check back soon — admin will post new tournaments.
          </div>
        )}
        {upcoming.map((m) => {
          const joined = joinedSet.has(m.id);
          const filled = counts[m.id] ?? 0;
          return (
            <Link
              key={m.id}
              to="/match/$matchId"
              params={{ matchId: m.id }}
              className="block soft-card rounded-xl p-4 space-y-3 hover:border-primary/40 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-bold truncate">{m.title}</div>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    <Tag>{m.mode}</Tag>
                    <Tag>{m.type}</Tag>
                    {m.region && <Tag tone="region"><MapPin className="h-3 w-3 inline mr-0.5" />{m.region}</Tag>}
                    <Tag tone={m.status === "live" ? "live" : "default"}>{m.status}</Tag>
                  </div>
                </div>
                <div className="text-right">
                  <div className="inline-flex items-center gap-1 text-warning font-bold">
                    <Coins className="h-4 w-4" /> {m.entry_fee}
                  </div>
                  <div className="text-[10px] text-muted-foreground">entry fee</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <Stat icon={Users} label={`${filled}/${m.max_players}`} sub="players" />
                <Stat icon={Trophy} label={`${m.prize_1 + m.prize_2 + m.prize_3 + m.prize_4 + m.prize_5}`} sub="prize pool" />
                <Stat icon={Clock} label={new Date(m.scheduled_at).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} sub="" />
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  🥇 {m.prize_1} • 🥈 {m.prize_2} • 🥉 {m.prize_3}
                </span>
                <span className="inline-flex items-center gap-0.5 text-primary font-medium">
                  {joined ? "✓ Joined" : "View details"} <ChevronRight className="h-3 w-3" />
                </span>
              </div>
            </Link>
          );
        })}
      </section>

      {past.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Recent Results</h2>
          {past.slice(0, 5).map((m) => {
            const myEntry = entries.find((e) => e.match_id === m.id);
            return (
              <div key={m.id} className="soft-card rounded-xl p-3 flex items-center justify-between">
                <div className="min-w-0">
                  <div className="font-medium truncate text-sm">{m.title}</div>
                  <div className="text-[11px] text-muted-foreground">{m.mode} • {m.type}</div>
                </div>
                {myEntry?.rank ? (
                  <div className="text-right">
                    <div className="font-bold text-primary">#{myEntry.rank}</div>
                    {myEntry.prize_coins > 0 && <div className="text-[11px] text-success">+{myEntry.prize_coins} coins</div>}
                  </div>
                ) : (
                  <div className="text-[11px] text-muted-foreground">—</div>
                )}
              </div>
            );
          })}
        </section>
      )}
    </div>
  );
}

function Tag({ children, tone = "default" }: { children: React.ReactNode; tone?: "default" | "live" | "region" }) {
  const cls = tone === "live" ? "bg-destructive/15 text-destructive"
    : tone === "region" ? "bg-primary/15 text-primary"
    : "bg-muted text-foreground";
  return <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold uppercase ${cls}`}>{children}</span>;
}
function Stat({ icon: Icon, label, sub }: { icon: React.ComponentType<{ className?: string }>; label: string; sub: string }) {
  return (
    <div className="rounded-lg bg-muted/50 p-2">
      <Icon className="h-3 w-3 text-muted-foreground mb-1" />
      <div className="font-semibold leading-tight">{label}</div>
      {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}