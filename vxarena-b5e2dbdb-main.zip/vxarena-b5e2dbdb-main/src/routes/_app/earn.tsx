import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Gift, Coins, Flame, CheckCircle2, Lock } from "lucide-react";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Streak = Database["public"]["Tables"]["login_streaks"]["Row"];

const REWARDS = [5, 10, 15, 20, 25, 30, 50];

export const Route = createFileRoute("/_app/earn")({
  head: () => ({ meta: [{ title: "Earn — VX Arena" }] }),
  component: EarnPage,
});

function EarnPage() {
  const { user } = useAuth();
  const [streak, setStreak] = useState<Streak | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from("login_streaks").select("*").eq("user_id", user.id).maybeSingle();
    setStreak(data);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const today = new Date().toISOString().slice(0, 10);
  const claimedToday = streak?.last_claim_date === today;

  // Determine which day is "next" to claim
  let nextDay = 1;
  if (streak) {
    const last = streak.last_claim_date ? new Date(streak.last_claim_date) : null;
    const todayD = new Date(today);
    const yesterday = new Date(todayD); yesterday.setDate(yesterday.getDate() - 1);
    const yStr = yesterday.toISOString().slice(0, 10);
    if (claimedToday) {
      nextDay = streak.current_day; // already done
    } else if (last && streak.last_claim_date === yStr) {
      nextDay = streak.current_day >= 7 ? 1 : streak.current_day + 1;
    } else {
      nextDay = 1; // missed or first time
    }
  }

  const claim = async () => {
    setBusy(true);
    const { data, error } = await supabase.rpc("claim_daily_reward");
    setBusy(false);
    if (error) return toast.error(error.message);
    const r = data as { day: number; reward: number };
    toast.success(`Day ${r.day} claimed — +${r.reward} coins!`);
    load();
  };

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="flex items-center gap-2">
        <Gift className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold">Earn Coins</h1>
      </div>

      <div className="soft-card rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-bold inline-flex items-center gap-1.5">
              <Flame className="h-5 w-5 text-warning" /> Daily Login Streak
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Login every day to earn more. Miss a day and the streak resets!
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-extrabold text-warning">{streak?.current_day ?? 0}</div>
            <div className="text-[10px] text-muted-foreground uppercase">day streak</div>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5">
          {REWARDS.map((reward, i) => {
            const day = i + 1;
            const isClaimed = streak ? day <= streak.current_day && (claimedToday || streak.current_day >= day) : false;
            const isNext = !claimedToday && day === nextDay;
            return (
              <div
                key={day}
                className={`rounded-lg p-2 text-center border-2 transition-all ${
                  isClaimed
                    ? "bg-success/10 border-success/40"
                    : isNext
                      ? "bg-primary/10 border-primary animate-pulse"
                      : "bg-muted/30 border-border"
                }`}
              >
                <div className="text-[10px] font-semibold text-muted-foreground">D{day}</div>
                <div className="my-1">
                  {isClaimed ? (
                    <CheckCircle2 className="h-4 w-4 mx-auto text-success" />
                  ) : (
                    <Coins className={`h-4 w-4 mx-auto ${isNext ? "text-primary" : "text-muted-foreground"}`} />
                  )}
                </div>
                <div className={`text-xs font-bold ${isClaimed ? "text-success" : isNext ? "text-primary" : ""}`}>
                  +{reward}
                </div>
              </div>
            );
          })}
        </div>

        <Button
          onClick={claim}
          disabled={busy || claimedToday}
          className="w-full bg-primary text-primary-foreground"
        >
          {claimedToday ? (
            <><CheckCircle2 className="h-4 w-4 mr-1" /> Claimed today — come back tomorrow</>
          ) : busy ? "Claiming..." : (
            <>Claim Day {nextDay} — +{REWARDS[nextDay - 1]} coins</>
          )}
        </Button>

        <div className="text-[11px] text-muted-foreground text-center">
          Total claims: {streak?.total_claims ?? 0} • Cycle resets after Day 7
        </div>
      </div>

      <div className="soft-card rounded-2xl p-5 opacity-60">
        <div className="flex items-center gap-2 mb-1">
          <Lock className="h-4 w-4" />
          <h2 className="font-semibold">More earning tasks coming soon</h2>
        </div>
        <p className="text-xs text-muted-foreground">
          Watch ads, refer friends, complete weekly challenges — stay tuned!
        </p>
      </div>
    </div>
  );
}