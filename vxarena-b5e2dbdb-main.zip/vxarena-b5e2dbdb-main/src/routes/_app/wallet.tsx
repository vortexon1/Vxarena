import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Coins, Gem, ArrowRightLeft, History, Send } from "lucide-react";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Wallet = Database["public"]["Tables"]["wallets"]["Row"];
type Txn = Database["public"]["Tables"]["wallet_transactions"]["Row"];

export const Route = createFileRoute("/_app/wallet")({
  head: () => ({ meta: [{ title: "Wallet — VX Arena" }] }),
  component: WalletPage,
});

function WalletPage() {
  const { user } = useAuth();
  const [w, setW] = useState<Wallet | null>(null);
  const [txns, setTxns] = useState<Txn[]>([]);
  const [packs, setPacks] = useState(1);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!user) return;
    const { data: wallet } = await supabase.from("wallets").select("*").eq("user_id", user.id).maybeSingle();
    setW(wallet);
    const { data: t } = await supabase.from("wallet_transactions").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(50);
    setTxns(t ?? []);
  };

  useEffect(() => { load(); }, [user]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase.channel("wallet-" + user.id)
      .on("postgres_changes", { event: "*", schema: "public", table: "wallets", filter: `user_id=eq.${user.id}` }, () => load())
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "wallet_transactions", filter: `user_id=eq.${user.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const exchange = async () => {
    setBusy(true);
    const { error } = await supabase.rpc("exchange_coins", { _packs: packs });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`Exchanged! +${packs * 100} diamonds`);
    load();
  };

  const coinsNeeded = packs * 1500;
  const diamondsGain = packs * 100;

  return (
    <div className="space-y-4 max-w-2xl">
      <h1 className="text-2xl font-bold">Wallet</h1>

      <div className="grid grid-cols-2 gap-3">
        <div className="soft-card rounded-2xl p-5 bg-gradient-to-br from-warning/10 to-transparent">
          <Coins className="h-6 w-6 text-warning mb-2" />
          <div className="text-3xl font-extrabold">{w?.coins ?? 0}</div>
          <div className="text-xs text-muted-foreground">Coins</div>
        </div>
        <div className="soft-card rounded-2xl p-5 bg-gradient-to-br from-primary/10 to-transparent">
          <Gem className="h-6 w-6 text-primary mb-2" />
          <div className="text-3xl font-extrabold">{w?.diamonds ?? 0}</div>
          <div className="text-xs text-muted-foreground">Diamonds</div>
        </div>
      </div>

      <Link to="/withdraw" className="block">
        <Button variant="outline" className="w-full">
          <Send className="h-4 w-4 mr-1" /> Withdraw Diamonds (min 100 💎)
        </Button>
      </Link>

      <div className="soft-card rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2">
          <ArrowRightLeft className="h-5 w-5 text-primary" />
          <h2 className="font-bold">Exchange Coins → Diamonds</h2>
        </div>
        <p className="text-xs text-muted-foreground">Rate: 1500 coins = 100 diamonds (1 pack)</p>
        <div className="flex items-center gap-2">
          <Input type="number" min={1} value={packs} onChange={(e) => setPacks(Math.max(1, parseInt(e.target.value) || 1))} className="w-24" />
          <span className="text-sm">packs</span>
        </div>
        <div className="text-sm rounded-lg bg-muted p-3 flex items-center justify-between">
          <span className="inline-flex items-center gap-1"><Coins className="h-4 w-4 text-warning" /> -{coinsNeeded}</span>
          <ArrowRightLeft className="h-4 w-4 text-muted-foreground" />
          <span className="inline-flex items-center gap-1"><Gem className="h-4 w-4 text-primary" /> +{diamondsGain}</span>
        </div>
        <Button onClick={exchange} disabled={busy || (w?.coins ?? 0) < coinsNeeded} className="w-full bg-primary text-primary-foreground">
          {busy ? "Exchanging..." : (w?.coins ?? 0) < coinsNeeded ? "Insufficient coins" : "Exchange now"}
        </Button>
      </div>

      <div className="soft-card rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-3">
          <History className="h-5 w-5 text-primary" />
          <h2 className="font-bold">History</h2>
        </div>
        {txns.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">No transactions yet</div>}
        <div className="divide-y divide-border">
          {txns.map((t) => (
            <div key={t.id} className="py-2.5 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{t.note ?? t.kind}</div>
                <div className="text-[11px] text-muted-foreground">{new Date(t.created_at).toLocaleString()}</div>
              </div>
              <div className="text-right text-sm">
                {t.coins_delta !== 0 && (
                  <div className={`font-semibold ${t.coins_delta > 0 ? "text-success" : "text-destructive"}`}>
                    {t.coins_delta > 0 ? "+" : ""}{t.coins_delta} 🪙
                  </div>
                )}
                {t.diamonds_delta !== 0 && (
                  <div className={`font-semibold ${t.diamonds_delta > 0 ? "text-success" : "text-destructive"}`}>
                    {t.diamonds_delta > 0 ? "+" : ""}{t.diamonds_delta} 💎
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}