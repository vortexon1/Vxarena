import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Trophy, Users, Coins, Clock, Key, Hash, RefreshCw, MapPin, Target } from "lucide-react";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Match = Database["public"]["Tables"]["matches"]["Row"];
type Entry = Database["public"]["Tables"]["match_entries"]["Row"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export const Route = createFileRoute("/_app/match/$matchId")({
  head: () => ({ meta: [{ title: "Match Details — VX Arena" }] }),
  component: MatchDetailsPage,
});

function MatchDetailsPage() {
  const { matchId } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [match, setMatch] = useState<Match | null>(null);
  const [entries, setEntries] = useState<(Entry & { profile?: Profile })[]>([]);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const { data: m } = await supabase.from("matches").select("*").eq("id", matchId).maybeSingle();
    setMatch(m);
    const { data: es } = await supabase.from("match_entries").select("*").eq("match_id", matchId);
    const ids = (es ?? []).map((e) => e.user_id);
    const { data: ps } = ids.length
      ? await supabase.from("profiles").select("*").in("id", ids)
      : { data: [] };
    const map = new Map((ps ?? []).map((p) => [p.id, p]));
    setEntries((es ?? []).map((e) => ({ ...e, profile: map.get(e.user_id) })));
  }, [matchId]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const ch = supabase.channel("match-detail-" + matchId)
      .on("postgres_changes", { event: "*", schema: "public", table: "matches", filter: `id=eq.${matchId}` }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "match_entries", filter: `match_id=eq.${matchId}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [matchId, load]);

  const refresh = async () => {
    setRefreshing(true);
    await load();
    setTimeout(() => setRefreshing(false), 400);
    toast.success("Refreshed");
  };

  const join = async () => {
    if (!match) return;
    setBusy(true);
    const { data, error } = await supabase.rpc("join_match", { _match_id: match.id });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Joined! Remaining coins: " + (data as { remaining_coins: number }).remaining_coins);
    load();
  };

  if (!match) return <div className="text-center py-12 text-muted-foreground">Loading match...</div>;

  const myEntry = entries.find((e) => e.user_id === user?.id);
  const joined = !!myEntry;
  const filled = entries.length;
  const totalPrize = match.prize_1 + match.prize_2 + match.prize_3 + match.prize_4 + match.prize_5;

  return (
    <div className="space-y-4 max-w-2xl">
      <button onClick={() => navigate({ to: "/matches" })} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to matches
      </button>

      <div className="soft-card rounded-2xl p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl font-bold">{match.title}</h1>
            <div className="flex flex-wrap gap-1.5 mt-2">
              <Tag>{match.mode}</Tag>
              <Tag>{match.type}</Tag>
              {match.region && <Tag tone="region"><MapPin className="h-3 w-3 inline mr-0.5" />{match.region}</Tag>}
              <Tag tone={match.status === "live" ? "live" : match.status === "completed" ? "muted" : "default"}>{match.status}</Tag>
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={refresh} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <Stat icon={Coins} label={`${match.entry_fee}`} sub="entry fee" />
          <Stat icon={Users} label={`${filled}/${match.max_players}`} sub="players" />
          <Stat icon={Clock} label={new Date(match.scheduled_at).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} sub="" />
        </div>

        <div className="rounded-xl bg-muted/50 p-3">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 inline-flex items-center gap-1">
            <Trophy className="h-3 w-3" /> Prize Pool — {totalPrize} coins
          </div>
          <div className="grid grid-cols-5 gap-1 text-center text-xs">
            <Prize place="1st" amount={match.prize_1} />
            <Prize place="2nd" amount={match.prize_2} />
            <Prize place="3rd" amount={match.prize_3} />
            <Prize place="4th" amount={match.prize_4} />
            <Prize place="5th" amount={match.prize_5} />
          </div>
        </div>

        {match.region && (
          <div className="rounded-lg bg-warning/10 border border-warning/30 p-3 text-xs flex items-start gap-2">
            <Target className="h-4 w-4 text-warning flex-shrink-0 mt-0.5" />
            <span><strong>Region locked:</strong> Only players from <strong>{match.region}</strong> can join this match.</span>
          </div>
        )}

        <div className="rounded-xl border border-border p-4 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm inline-flex items-center gap-1.5">
              <Key className="h-4 w-4 text-primary" /> Room Credentials
            </h3>
            <Button size="sm" variant="ghost" onClick={refresh} disabled={refreshing} className="h-7 text-xs">
              <RefreshCw className={`h-3 w-3 mr-1 ${refreshing ? "animate-spin" : ""}`} /> Refresh
            </Button>
          </div>
          {joined ? (
            match.room_id_text ? (
              <div className="space-y-2">
                <CredRow icon={Hash} label="Room ID" value={match.room_id_text} />
                {match.room_password && <CredRow icon={Key} label="Password" value={match.room_password} />}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground py-2">
                Admin has not set room credentials yet. Tap <strong>Refresh</strong> closer to match time.
              </p>
            )
          ) : (
            <p className="text-xs text-muted-foreground py-2">Join the match to see room ID and password.</p>
          )}
        </div>

        {joined ? (
          <Button disabled className="w-full" variant="outline">
            ✓ You have joined {myEntry?.rank ? `— Rank #${myEntry.rank}` : ""}
          </Button>
        ) : (
          <Button
            onClick={join}
            disabled={busy || filled >= match.max_players || match.status !== "upcoming"}
            className="w-full bg-primary text-primary-foreground"
          >
            {busy ? "Joining..." : filled >= match.max_players ? "Match full" : match.status !== "upcoming" ? "Not open" : `Join — ${match.entry_fee} coins`}
          </Button>
        )}

        <div>
          <h3 className="font-semibold text-sm mb-2">Players ({filled})</h3>
          {entries.length === 0 && <p className="text-xs text-muted-foreground">No players joined yet.</p>}
          <div className="space-y-1.5">
            {entries.map((e) => (
              <div key={e.id} className="flex items-center justify-between text-sm rounded-lg bg-muted/30 px-3 py-2">
                <span className="truncate">
                  {e.profile?.ingame_name ?? "Player"}
                  <span className="text-muted-foreground text-xs ml-1">({e.profile?.ingame_uid ?? "—"})</span>
                </span>
                {e.rank ? <span className="text-xs font-bold text-primary">#{e.rank}</span> : null}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Tag({ children, tone = "default" }: { children: React.ReactNode; tone?: "default" | "live" | "muted" | "region" }) {
  const cls =
    tone === "live" ? "bg-destructive/15 text-destructive"
    : tone === "muted" ? "bg-muted text-muted-foreground"
    : tone === "region" ? "bg-primary/15 text-primary"
    : "bg-muted text-foreground";
  return <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold uppercase ${cls}`}>{children}</span>;
}
function Stat({ icon: Icon, label, sub }: { icon: React.ComponentType<{ className?: string }>; label: string; sub: string }) {
  return (
    <div className="rounded-lg bg-muted/50 p-2">
      <Icon className="h-3 w-3 text-muted-foreground mb-1" />
      <div className="font-semibold leading-tight text-sm">{label}</div>
      {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}
function Prize({ place, amount }: { place: string; amount: number }) {
  return (
    <div className="rounded-md bg-background p-2">
      <div className="text-[10px] text-muted-foreground">{place}</div>
      <div className="font-bold text-warning">{amount}</div>
    </div>
  );
}
function CredRow({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-primary/10 border border-primary/30 p-2.5">
      <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {label}
      </span>
      <span className="font-mono font-bold text-sm">{value}</span>
    </div>
  );
}