import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { generatePlayerId } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";
import { Upload, Image as ImageIcon, AlertTriangle } from "lucide-react";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

type Region = Database["public"]["Enums"]["player_region"];
type Role = Database["public"]["Enums"]["player_role"];

const REGIONS: Region[] = ["Pakistan", "India", "Bangladesh", "Indonesia", "Nepal", "Brazil", "Others"];
const ROLES: Role[] = ["Rusher", "Sniper", "Support"];

export const Route = createFileRoute("/profile-setup")({
  head: () => ({ meta: [{ title: "Set up your profile — VX Arena" }] }),
  component: ProfileSetupPage,
});

const schema = z.object({
  ingame_name: z.string().trim().min(2, "Name must be at least 2 characters").max(30),
  ingame_uid: z.string().trim().min(4, "Free Fire UID is required").max(20),
});

function ProfileSetupPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [uid, setUid] = useState("");
  const [region, setRegion] = useState<Region>("Pakistan");
  const [role, setRole] = useState<Role>("Rusher");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/login" });
  }, [user, authLoading, navigate]);

  // If profile already complete, skip
  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("profile_completed").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data?.profile_completed) navigate({ to: "/matches" });
    });
  }, [user, navigate]);

  const onFile = (f: File | null) => {
    if (!f) return;
    if (!f.type.startsWith("image/")) return toast.error("Please upload an image file");
    if (f.size > 5 * 1024 * 1024) return toast.error("Image must be under 5MB");
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const parsed = schema.safeParse({ ingame_name: name, ingame_uid: uid });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    if (!file) return toast.error("Free Fire profile screenshot is required");

    setSaving(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${user.id}/ff-profile-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("ff-screenshots").upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("ff-screenshots").getPublicUrl(path);

      // Upsert profile (insert if new, update if pending)
      const { error } = await supabase.from("profiles").upsert({
        id: user.id,
        player_id: generatePlayerId(),
        ingame_name: parsed.data.ingame_name,
        ingame_uid: parsed.data.ingame_uid,
        region,
        role,
        ff_screenshot_url: pub.publicUrl,
        status: "Online",
        profile_completed: true,
      }, { onConflict: "id" });
      if (error) throw error;
      toast.success("Profile ready! Welcome to VX Arena 🎉");
      navigate({ to: "/matches" });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Profile save failed";
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  if (authLoading) return <div className="min-h-screen flex items-center justify-center">Loading…</div>;

  return (
    <div className="min-h-screen p-4 py-8">
      <div className="max-w-md mx-auto soft-card rounded-2xl p-6">
        <div className="text-center mb-6">
          <div className="inline-flex"><Logo size={56} /></div>
          <h1 className="text-2xl font-bold mt-3">Set up your profile</h1>
          <p className="text-sm text-muted-foreground">Complete your profile to start playing. You can edit it later.</p>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <Label htmlFor="name">In-game name *</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={30} required />
          </div>
          <div>
            <Label htmlFor="uid">Free Fire UID *</Label>
            <Input id="uid" value={uid} onChange={(e) => setUid(e.target.value)} maxLength={20} required placeholder="e.g. 1234567890" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Region *</Label>
              <Select value={region} onValueChange={(v) => setRegion(v as Region)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REGIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Role</Label>
              <Select value={role} onValueChange={(v) => setRole(v as Role)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="rounded-lg bg-warning/10 border border-warning/40 p-3 text-xs flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-warning flex-shrink-0 mt-0.5" />
            <span>
              <strong>Important:</strong> Choose your region <strong>correctly</strong>. Matches are region-locked —
              if you pick the wrong region, you will not be able to join your local tournaments.
              You will be responsible for any issues caused by an incorrect region.
            </span>
          </div>
          <div>
            <Label>FF profile screenshot *</Label>
            <label className="mt-1 flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-border p-6 cursor-pointer hover:border-primary/60 transition-colors">
              {preview ? (
                <img src={preview} alt="preview" className="max-h-48 rounded-lg object-contain" />
              ) : (
                <>
                  <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                  <span className="text-sm font-medium">Tap to upload screenshot</span>
                  <span className="text-xs text-muted-foreground mt-1">PNG/JPG, max 5MB</span>
                </>
              )}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
            </label>
            <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
              <ImageIcon className="h-3 w-3" /> Upload a screenshot of your in-game Free Fire profile.
            </p>
          </div>
          <Button type="submit" disabled={saving} className="w-full bg-primary text-primary-foreground">
            {saving ? "Saving..." : "Complete profile"}
          </Button>
        </form>
      </div>
    </div>
  );
}