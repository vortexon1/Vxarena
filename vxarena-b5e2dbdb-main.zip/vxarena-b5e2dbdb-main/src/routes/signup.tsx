import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";
import { z } from "zod";

export const Route = createFileRoute("/signup")({
  head: () => ({ meta: [{ title: "Sign Up — VX Arena" }] }),
  component: SignupPage,
});

const schema = z.object({
  email: z.string().trim().email("Sahih email enter karo").max(255),
  password: z.string().min(6, "Password minimum 6 characters"),
});

function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: { emailRedirectTo: window.location.origin + "/profile-setup" },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    setSent(true);
    toast.success("Confirmation email bhej dia gaya!");
  };

  if (sent) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md soft-card rounded-2xl p-8 text-center">
          <Logo size={64} />
          <h1 className="text-2xl font-bold mt-4">Check your email</h1>
          <p className="text-sm text-muted-foreground mt-2">
            Humne <strong>{email}</strong> par confirmation link bheja hai. Email open karke link click karo, phir login karo aur apni profile set karo.
          </p>
          <Button className="mt-6 w-full" onClick={() => navigate({ to: "/login" })}>Go to login</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md soft-card rounded-2xl p-8">
        <div className="text-center mb-6">
          <div className="inline-flex"><Logo size={56} /></div>
          <h1 className="text-2xl font-bold mt-3">Join VX Arena</h1>
          <p className="text-sm text-muted-foreground">Email se signup karo — OTP confirmation aayegi</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="Min 6 characters" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <Button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground">
            {loading ? "Creating..." : "Create account"}
          </Button>
        </form>
        <p className="text-center text-sm text-muted-foreground mt-4">
          Already a player? <Link to="/login" className="text-primary font-medium">Login</Link>
        </p>
      </div>
    </div>
  );
}