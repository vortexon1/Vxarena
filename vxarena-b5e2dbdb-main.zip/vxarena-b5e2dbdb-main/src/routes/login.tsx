import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Login — VX Arena" }] }),
  component: LoginPage,
});

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || password.length < 6) return toast.error("Enter a valid email and password");
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) {
      setLoading(false);
      return toast.error(error.message);
    }
    // Check if profile exists & completed
    const { data: prof } = await supabase
      .from("profiles")
      .select("profile_completed")
      .eq("id", data.user.id)
      .maybeSingle();
    setLoading(false);
    toast.success("Welcome back!");
    if (!prof || !prof.profile_completed) navigate({ to: "/profile-setup" });
    else navigate({ to: "/matches" });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md soft-card rounded-2xl p-8">
        <div className="text-center mb-6">
          <div className="inline-flex"><Logo size={56} /></div>
          <h1 className="text-2xl font-bold mt-3">Welcome back</h1>
          <p className="text-sm text-muted-foreground">Sign in to your VX Arena account</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <Button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground">
            {loading ? "Signing in..." : "Login"}
          </Button>
          <div className="text-right">
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</Link>
          </div>
        </form>
        <p className="text-center text-sm text-muted-foreground mt-6">
          New here? <Link to="/signup" className="text-primary font-medium">Create account</Link>
        </p>
      </div>
    </div>
  );
}