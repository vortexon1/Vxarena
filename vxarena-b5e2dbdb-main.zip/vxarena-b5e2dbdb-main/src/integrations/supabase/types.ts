export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      login_streaks: {
        Row: {
          current_day: number
          last_claim_date: string | null
          total_claims: number
          updated_at: string
          user_id: string
        }
        Insert: {
          current_day?: number
          last_claim_date?: string | null
          total_claims?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          current_day?: number
          last_claim_date?: string | null
          total_claims?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      match_entries: {
        Row: {
          id: string
          joined_at: string
          match_id: string
          prize_coins: number
          rank: number | null
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string
          match_id: string
          prize_coins?: number
          rank?: number | null
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string
          match_id?: string
          prize_coins?: number
          rank?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "match_entries_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
        ]
      }
      matches: {
        Row: {
          created_at: string
          created_by: string
          entry_fee: number
          id: string
          max_players: number
          mode: Database["public"]["Enums"]["match_mode"]
          prize_1: number
          prize_2: number
          prize_3: number
          prize_4: number
          prize_5: number
          region: Database["public"]["Enums"]["player_region"] | null
          room_id_text: string | null
          room_password: string | null
          scheduled_at: string
          status: Database["public"]["Enums"]["match_status"]
          title: string
          type: Database["public"]["Enums"]["match_type"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          entry_fee?: number
          id?: string
          max_players: number
          mode: Database["public"]["Enums"]["match_mode"]
          prize_1?: number
          prize_2?: number
          prize_3?: number
          prize_4?: number
          prize_5?: number
          region?: Database["public"]["Enums"]["player_region"] | null
          room_id_text?: string | null
          room_password?: string | null
          scheduled_at: string
          status?: Database["public"]["Enums"]["match_status"]
          title: string
          type: Database["public"]["Enums"]["match_type"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          entry_fee?: number
          id?: string
          max_players?: number
          mode?: Database["public"]["Enums"]["match_mode"]
          prize_1?: number
          prize_2?: number
          prize_3?: number
          prize_4?: number
          prize_5?: number
          region?: Database["public"]["Enums"]["player_region"] | null
          room_id_text?: string | null
          room_password?: string | null
          scheduled_at?: string
          status?: Database["public"]["Enums"]["match_status"]
          title?: string
          type?: Database["public"]["Enums"]["match_type"]
          updated_at?: string
        }
        Relationships: []
      }
      notification_reads: {
        Row: {
          notification_id: string
          read_at: string
          user_id: string
        }
        Insert: {
          notification_id: string
          read_at?: string
          user_id: string
        }
        Update: {
          notification_id?: string
          read_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notification_reads_notification_id_fkey"
            columns: ["notification_id"]
            isOneToOne: false
            referencedRelation: "notifications"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          created_by: string
          id: string
          is_broadcast: boolean
          kind: string
          target_user_id: string | null
          title: string
        }
        Insert: {
          body: string
          created_at?: string
          created_by: string
          id?: string
          is_broadcast?: boolean
          kind?: string
          target_user_id?: string | null
          title: string
        }
        Update: {
          body?: string
          created_at?: string
          created_by?: string
          id?: string
          is_broadcast?: boolean
          kind?: string
          target_user_id?: string | null
          title?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          availability: Database["public"]["Enums"]["availability"]
          avatar_url: string | null
          bio: string | null
          created_at: string
          ff_screenshot_url: string | null
          id: string
          ingame_name: string
          ingame_uid: string | null
          is_banned: boolean
          last_seen: string
          phone: string | null
          player_id: string
          playstyle: Database["public"]["Enums"]["playstyle"]
          profile_completed: boolean
          region: Database["public"]["Enums"]["player_region"] | null
          role: Database["public"]["Enums"]["player_role"]
          status: Database["public"]["Enums"]["online_status"]
          updated_at: string
        }
        Insert: {
          availability?: Database["public"]["Enums"]["availability"]
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          ff_screenshot_url?: string | null
          id: string
          ingame_name: string
          ingame_uid?: string | null
          is_banned?: boolean
          last_seen?: string
          phone?: string | null
          player_id: string
          playstyle?: Database["public"]["Enums"]["playstyle"]
          profile_completed?: boolean
          region?: Database["public"]["Enums"]["player_region"] | null
          role?: Database["public"]["Enums"]["player_role"]
          status?: Database["public"]["Enums"]["online_status"]
          updated_at?: string
        }
        Update: {
          availability?: Database["public"]["Enums"]["availability"]
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          ff_screenshot_url?: string | null
          id?: string
          ingame_name?: string
          ingame_uid?: string | null
          is_banned?: boolean
          last_seen?: string
          phone?: string | null
          player_id?: string
          playstyle?: Database["public"]["Enums"]["playstyle"]
          profile_completed?: boolean
          region?: Database["public"]["Enums"]["player_region"] | null
          role?: Database["public"]["Enums"]["player_role"]
          status?: Database["public"]["Enums"]["online_status"]
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallet_transactions: {
        Row: {
          coins_delta: number
          created_at: string
          diamonds_delta: number
          id: string
          kind: Database["public"]["Enums"]["txn_kind"]
          match_id: string | null
          note: string | null
          user_id: string
        }
        Insert: {
          coins_delta?: number
          created_at?: string
          diamonds_delta?: number
          id?: string
          kind: Database["public"]["Enums"]["txn_kind"]
          match_id?: string | null
          note?: string | null
          user_id: string
        }
        Update: {
          coins_delta?: number
          created_at?: string
          diamonds_delta?: number
          id?: string
          kind?: Database["public"]["Enums"]["txn_kind"]
          match_id?: string | null
          note?: string | null
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          coins: number
          created_at: string
          diamonds: number
          updated_at: string
          user_id: string
        }
        Insert: {
          coins?: number
          created_at?: string
          diamonds?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          coins?: number
          created_at?: string
          diamonds?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      withdrawal_requests: {
        Row: {
          admin_note: string | null
          created_at: string
          diamonds: number
          gmail: string
          id: string
          ingame_uid: string
          status: Database["public"]["Enums"]["withdrawal_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          created_at?: string
          diamonds: number
          gmail: string
          id?: string
          ingame_uid: string
          status?: Database["public"]["Enums"]["withdrawal_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          created_at?: string
          diamonds?: number
          gmail?: string
          id?: string
          ingame_uid?: string
          status?: Database["public"]["Enums"]["withdrawal_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_daily_reward: { Args: never; Returns: Json }
      exchange_coins: { Args: { _packs: number }; Returns: Json }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      join_match: { Args: { _match_id: string }; Returns: Json }
      set_match_ranks: {
        Args: { _match_id: string; _ranks: Json }
        Returns: Json
      }
      set_withdrawal_status: {
        Args: {
          _note?: string
          _request_id: string
          _status: Database["public"]["Enums"]["withdrawal_status"]
        }
        Returns: Json
      }
      submit_withdrawal: {
        Args: { _diamonds: number; _gmail: string; _ingame_uid: string }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin" | "user"
      availability: "Morning" | "Evening" | "Night"
      friendship_status: "pending" | "accepted" | "rejected"
      match_mode: "1v1" | "2v2" | "3v3" | "4v4" | "50p"
      match_status: "upcoming" | "live" | "completed" | "cancelled"
      match_type: "booyah" | "kill" | "survive"
      online_status: "Online" | "In Match" | "Offline"
      player_region:
        | "Pakistan"
        | "India"
        | "Bangladesh"
        | "Indonesia"
        | "Nepal"
        | "Brazil"
        | "Others"
      player_role: "Rusher" | "Sniper" | "Support"
      playstyle: "Aggressive" | "Passive"
      rating_type: "good" | "toxic" | "inactive"
      report_reason: "toxic" | "fake_profile" | "abuse"
      report_status: "pending" | "warned" | "banned" | "ignored"
      txn_kind:
        | "signup_bonus"
        | "entry_fee"
        | "prize"
        | "exchange_coins_out"
        | "exchange_diamonds_in"
        | "admin_adjust"
        | "daily_reward"
        | "withdrawal_hold"
        | "withdrawal_refund"
        | "withdrawal_paid"
      withdrawal_status: "pending" | "approved" | "rejected" | "paid"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      availability: ["Morning", "Evening", "Night"],
      friendship_status: ["pending", "accepted", "rejected"],
      match_mode: ["1v1", "2v2", "3v3", "4v4", "50p"],
      match_status: ["upcoming", "live", "completed", "cancelled"],
      match_type: ["booyah", "kill", "survive"],
      online_status: ["Online", "In Match", "Offline"],
      player_region: [
        "Pakistan",
        "India",
        "Bangladesh",
        "Indonesia",
        "Nepal",
        "Brazil",
        "Others",
      ],
      player_role: ["Rusher", "Sniper", "Support"],
      playstyle: ["Aggressive", "Passive"],
      rating_type: ["good", "toxic", "inactive"],
      report_reason: ["toxic", "fake_profile", "abuse"],
      report_status: ["pending", "warned", "banned", "ignored"],
      txn_kind: [
        "signup_bonus",
        "entry_fee",
        "prize",
        "exchange_coins_out",
        "exchange_diamonds_in",
        "admin_adjust",
        "daily_reward",
        "withdrawal_hold",
        "withdrawal_refund",
        "withdrawal_paid",
      ],
      withdrawal_status: ["pending", "approved", "rejected", "paid"],
    },
  },
} as const
