import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { Trophy, Wallet, User, Shield, LogOut, Gift, Bell } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

export function AppShell({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAdmin, signOut } = useAuth();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      const { data: notifs } = await supabase
        .from("notifications")
        .select("id")
        .or(`is_broadcast.eq.true,target_user_id.eq.${user.id}`);
      const { data: reads } = await supabase
        .from("notification_reads")
        .select("notification_id")
        .eq("user_id", user.id);
      const readSet = new Set((reads ?? []).map((r) => r.notification_id));
      setUnread((notifs ?? []).filter((n) => !readSet.has(n.id)).length);
    };
    load();
    const ch = supabase
      .channel("notif-badge")
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "notification_reads" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user, location.pathname]);

  const navItems = [
    { to: "/matches" as const, label: "Matches", icon: Trophy },
    { to: "/earn" as const, label: "Earn", icon: Gift },
    { to: "/wallet" as const, label: "Wallet", icon: Wallet },
    { to: "/profile" as const, label: "Profile", icon: User },
  ];

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-64 bg-background">
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="mx-auto flex h-14 items-center justify-between px-4">
          <Link to="/matches" className="flex items-center gap-2">
            <Logo size={32} />
            <span className="font-bold text-base tracking-tight">
              VX <span className="text-primary">Arena</span>
            </span>
          </Link>
          <div className="flex items-center gap-1">
            <Button size="sm" variant="ghost" onClick={() => navigate({ to: "/notifications" })} className="relative">
              <Bell className="h-4 w-4" />
              {unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground flex items-center justify-center">
                  {unread > 9 ? "9+" : unread}
                </span>
              )}
            </Button>
            {isAdmin && (
              <Button size="sm" variant="ghost" onClick={() => navigate({ to: "/admin" })}>
                <Shield className="h-4 w-4 mr-1" /> Admin
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={async () => { await signOut(); navigate({ to: "/" }); }}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <aside className="hidden md:flex fixed left-0 top-14 bottom-0 w-64 flex-col border-r border-border bg-sidebar p-4 gap-1">
        {navItems.map((item) => {
          const active = location.pathname.startsWith(item.to);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Link>
          );
        })}
        <div className="mt-auto text-xs text-muted-foreground px-3 truncate">
          {user?.email}
        </div>
      </aside>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border">
        <div className="grid grid-cols-4">
          {navItems.map((item) => {
            const active = location.pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex flex-col items-center gap-0.5 py-2.5 text-[10px] transition-colors ${
                  active ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      <main className="mx-auto max-w-5xl p-4 md:p-6">{children}</main>
    </div>
  );
}

export function StatusBadge({ status }: { status: "Online" | "In Match" | "Offline" }) {
  const map = {
    Online: "bg-success/15 text-success border border-success/30",
    "In Match": "bg-warning/15 text-warning border border-warning/30",
    Offline: "bg-muted text-muted-foreground border border-border",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium ${map[status]}`}>
      <span className={`h-1.5 w-1.5 rounded-full bg-current ${status === "Online" ? "animate-pulse" : ""}`} />
      {status}
    </span>
  );
}