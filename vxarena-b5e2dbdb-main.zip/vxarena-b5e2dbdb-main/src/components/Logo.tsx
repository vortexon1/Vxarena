import logoImg from "@/assets/vx-logo.jpg";

export function Logo({ size = 36, withText = false }: { size?: number; withText?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2">
      <img
        src={logoImg}
        alt="VX Arena logo"
        width={size}
        height={size}
        className="rounded-lg object-cover"
        style={{ width: size, height: size }}
      />
      {withText && (
        <span className="font-extrabold tracking-tight text-lg">
          VX <span className="text-primary">Arena</span>
        </span>
      )}
    </span>
  );
}