
REVOKE EXECUTE ON FUNCTION public.join_match(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.set_match_ranks(uuid, jsonb) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.exchange_coins(int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.join_match(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_match_ranks(uuid, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.exchange_coins(int) TO authenticated;
