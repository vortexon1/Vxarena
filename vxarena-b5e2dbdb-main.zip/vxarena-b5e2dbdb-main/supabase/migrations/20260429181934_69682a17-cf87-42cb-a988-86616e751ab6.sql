-- Tighten storage SELECT (still public-ish via authenticated, screenshots only show in app)
DROP POLICY IF EXISTS "FF screenshots are public" ON storage.objects;
CREATE POLICY "FF screenshots viewable by authenticated" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'ff-screenshots');

-- Lock down SECURITY DEFINER helpers (RLS still works because policies run as the table owner)
REVOKE EXECUTE ON FUNCTION public.is_room_member(uuid, uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user_role() FROM PUBLIC, anon, authenticated;