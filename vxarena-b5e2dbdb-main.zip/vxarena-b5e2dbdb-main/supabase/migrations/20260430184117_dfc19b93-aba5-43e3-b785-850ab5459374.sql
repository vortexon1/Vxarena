-- 1. Region-lock in join_match
CREATE OR REPLACE FUNCTION public.join_match(_match_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE _uid uuid := auth.uid(); _m record; _count int; _bal int; _player_region player_region;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT * INTO _m FROM public.matches WHERE id = _match_id FOR UPDATE;
  IF _m IS NULL THEN RAISE EXCEPTION 'Match not found'; END IF;
  IF _m.status <> 'upcoming' THEN RAISE EXCEPTION 'Match not open'; END IF;

  IF _m.region IS NOT NULL THEN
    SELECT region INTO _player_region FROM public.profiles WHERE id = _uid;
    IF _player_region IS NULL THEN RAISE EXCEPTION 'Set your region in profile first'; END IF;
    IF _player_region <> _m.region THEN
      RAISE EXCEPTION 'This match is for % region only. Your region is %.', _m.region, _player_region;
    END IF;
  END IF;

  SELECT COUNT(*) INTO _count FROM public.match_entries WHERE match_id = _match_id;
  IF _count >= _m.max_players THEN RAISE EXCEPTION 'Match full'; END IF;
  IF EXISTS (SELECT 1 FROM public.match_entries WHERE match_id = _match_id AND user_id = _uid) THEN RAISE EXCEPTION 'Already joined'; END IF;
  SELECT coins INTO _bal FROM public.wallets WHERE user_id = _uid FOR UPDATE;
  IF _bal IS NULL THEN INSERT INTO public.wallets(user_id, coins) VALUES (_uid, 0); _bal := 0; END IF;
  IF _bal < _m.entry_fee THEN RAISE EXCEPTION 'Insufficient coins'; END IF;
  UPDATE public.wallets SET coins = coins - _m.entry_fee WHERE user_id = _uid;
  INSERT INTO public.wallet_transactions(user_id, kind, coins_delta, match_id, note) VALUES (_uid,'entry_fee',-_m.entry_fee,_match_id,'Match entry: '||_m.title);
  INSERT INTO public.match_entries(match_id, user_id) VALUES (_match_id, _uid);
  RETURN jsonb_build_object('ok', true, 'remaining_coins', _bal - _m.entry_fee);
END $function$;

-- 2. Login streak table
CREATE TABLE public.login_streaks (
  user_id uuid PRIMARY KEY,
  current_day int NOT NULL DEFAULT 0,
  last_claim_date date,
  total_claims int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.login_streaks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner views own streak" ON public.login_streaks FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));

-- Extend txn_kind enum
ALTER TYPE txn_kind ADD VALUE IF NOT EXISTS 'daily_reward';
ALTER TYPE txn_kind ADD VALUE IF NOT EXISTS 'withdrawal_hold';
ALTER TYPE txn_kind ADD VALUE IF NOT EXISTS 'withdrawal_refund';
ALTER TYPE txn_kind ADD VALUE IF NOT EXISTS 'withdrawal_paid';

-- 3. Withdrawal status enum + table
CREATE TYPE withdrawal_status AS ENUM ('pending','approved','rejected','paid');

CREATE TABLE public.withdrawal_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  diamonds int NOT NULL CHECK (diamonds >= 100),
  gmail text NOT NULL,
  ingame_uid text NOT NULL,
  status withdrawal_status NOT NULL DEFAULT 'pending',
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner views own withdrawals" ON public.withdrawal_requests
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));

CREATE POLICY "Admin updates withdrawals" ON public.withdrawal_requests
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(),'admin'));

CREATE TRIGGER touch_withdrawal_requests
  BEFORE UPDATE ON public.withdrawal_requests
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.login_streaks REPLICA IDENTITY FULL;
ALTER TABLE public.withdrawal_requests REPLICA IDENTITY FULL;