-- Daily reward claim
CREATE OR REPLACE FUNCTION public.claim_daily_reward()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  _uid uuid := auth.uid();
  _row record;
  _today date := (now() AT TIME ZONE 'UTC')::date;
  _next_day int;
  _reward int;
  _rewards int[] := ARRAY[5,10,15,20,25,30,50];
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  SELECT * INTO _row FROM public.login_streaks WHERE user_id = _uid FOR UPDATE;
  IF _row IS NULL THEN
    INSERT INTO public.login_streaks(user_id, current_day, last_claim_date, total_claims)
    VALUES (_uid, 0, NULL, 0);
    _row.current_day := 0; _row.last_claim_date := NULL;
  END IF;

  IF _row.last_claim_date = _today THEN
    RAISE EXCEPTION 'Already claimed today. Come back tomorrow.';
  END IF;

  IF _row.last_claim_date IS NULL OR _row.last_claim_date < _today - INTERVAL '1 day' THEN
    _next_day := 1;
  ELSE
    IF _row.current_day >= 7 THEN _next_day := 1; ELSE _next_day := _row.current_day + 1; END IF;
  END IF;

  _reward := _rewards[_next_day];

  UPDATE public.login_streaks
    SET current_day = _next_day, last_claim_date = _today, total_claims = total_claims + 1, updated_at = now()
  WHERE user_id = _uid;

  INSERT INTO public.wallets(user_id, coins) VALUES (_uid, _reward)
    ON CONFLICT (user_id) DO UPDATE SET coins = wallets.coins + _reward;

  INSERT INTO public.wallet_transactions(user_id, kind, coins_delta, note)
  VALUES (_uid, 'daily_reward', _reward, 'Day '||_next_day||' login streak');

  RETURN jsonb_build_object('ok', true, 'day', _next_day, 'reward', _reward);
END $function$;

REVOKE ALL ON FUNCTION public.claim_daily_reward() FROM anon, public;
GRANT EXECUTE ON FUNCTION public.claim_daily_reward() TO authenticated;

-- Submit withdrawal
CREATE OR REPLACE FUNCTION public.submit_withdrawal(_diamonds int, _gmail text, _ingame_uid text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE _uid uuid := auth.uid(); _bal int; _req_id uuid;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _diamonds < 100 THEN RAISE EXCEPTION 'Minimum withdrawal is 100 diamonds'; END IF;
  IF _gmail IS NULL OR length(trim(_gmail)) < 5 OR position('@' in _gmail) = 0 THEN
    RAISE EXCEPTION 'Valid Gmail required';
  END IF;
  IF _ingame_uid IS NULL OR length(trim(_ingame_uid)) < 4 THEN
    RAISE EXCEPTION 'In-game UID required';
  END IF;

  SELECT diamonds INTO _bal FROM public.wallets WHERE user_id = _uid FOR UPDATE;
  IF _bal IS NULL OR _bal < _diamonds THEN RAISE EXCEPTION 'Insufficient diamonds'; END IF;

  UPDATE public.wallets SET diamonds = diamonds - _diamonds WHERE user_id = _uid;

  INSERT INTO public.withdrawal_requests(user_id, diamonds, gmail, ingame_uid)
  VALUES (_uid, _diamonds, trim(_gmail), trim(_ingame_uid))
  RETURNING id INTO _req_id;

  INSERT INTO public.wallet_transactions(user_id, kind, diamonds_delta, note)
  VALUES (_uid, 'withdrawal_hold', -_diamonds, 'Withdrawal request '||_req_id);

  RETURN jsonb_build_object('ok', true, 'request_id', _req_id);
END $function$;

REVOKE ALL ON FUNCTION public.submit_withdrawal(int,text,text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.submit_withdrawal(int,text,text) TO authenticated;

-- Admin sets withdrawal status
CREATE OR REPLACE FUNCTION public.set_withdrawal_status(_request_id uuid, _status withdrawal_status, _note text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE _r record;
BEGIN
  IF NOT has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  SELECT * INTO _r FROM public.withdrawal_requests WHERE id = _request_id FOR UPDATE;
  IF _r IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF _r.status <> 'pending' THEN RAISE EXCEPTION 'Already processed'; END IF;

  IF _status = 'rejected' THEN
    UPDATE public.wallets SET diamonds = diamonds + _r.diamonds WHERE user_id = _r.user_id;
    INSERT INTO public.wallet_transactions(user_id, kind, diamonds_delta, note)
    VALUES (_r.user_id, 'withdrawal_refund', _r.diamonds, 'Withdrawal rejected'||COALESCE(': '||_note,''));
  ELSIF _status IN ('approved','paid') THEN
    INSERT INTO public.wallet_transactions(user_id, kind, diamonds_delta, note)
    VALUES (_r.user_id, 'withdrawal_paid', 0, 'Withdrawal '||_status||COALESCE(': '||_note,''));
  END IF;

  UPDATE public.withdrawal_requests SET status = _status, admin_note = _note WHERE id = _request_id;
  RETURN jsonb_build_object('ok', true);
END $function$;

REVOKE ALL ON FUNCTION public.set_withdrawal_status(uuid,withdrawal_status,text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.set_withdrawal_status(uuid,withdrawal_status,text) TO authenticated;