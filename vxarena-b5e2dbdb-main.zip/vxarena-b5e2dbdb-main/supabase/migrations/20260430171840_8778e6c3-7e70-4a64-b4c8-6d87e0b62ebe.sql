
DROP TABLE IF EXISTS public.room_messages CASCADE;
DROP TABLE IF EXISTS public.room_members CASCADE;
DROP TABLE IF EXISTS public.rooms CASCADE;
DROP TABLE IF EXISTS public.messages CASCADE;
DROP TABLE IF EXISTS public.friendships CASCADE;
DROP TABLE IF EXISTS public.blocks CASCADE;
DROP TABLE IF EXISTS public.reports CASCADE;
DROP FUNCTION IF EXISTS public.is_room_member(uuid, uuid) CASCADE;

DO $$ BEGIN CREATE TYPE public.match_mode AS ENUM ('1v1','2v2','3v3','4v4','50p'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE public.match_type AS ENUM ('booyah','kill','survive'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE public.match_status AS ENUM ('upcoming','live','completed','cancelled'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE public.txn_kind AS ENUM ('signup_bonus','entry_fee','prize','exchange_coins_out','exchange_diamonds_in','admin_adjust'); EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE public.wallets (
  user_id uuid PRIMARY KEY,
  coins integer NOT NULL DEFAULT 0,
  diamonds integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (coins >= 0 AND diamonds >= 0)
);
ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner views own wallet" ON public.wallets FOR SELECT TO authenticated USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE POLICY "Admin updates wallets" ON public.wallets FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_wallets_updated BEFORE UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
ALTER TABLE public.wallets REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.wallets;

CREATE TABLE public.wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  kind public.txn_kind NOT NULL,
  coins_delta integer NOT NULL DEFAULT 0,
  diamonds_delta integer NOT NULL DEFAULT 0,
  match_id uuid,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner views own txns" ON public.wallet_transactions FOR SELECT TO authenticated USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE INDEX idx_txn_user ON public.wallet_transactions(user_id, created_at DESC);

CREATE TABLE public.matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  mode public.match_mode NOT NULL,
  type public.match_type NOT NULL,
  region public.player_region,
  entry_fee integer NOT NULL DEFAULT 30 CHECK (entry_fee >= 0),
  max_players integer NOT NULL CHECK (max_players > 0),
  prize_1 integer NOT NULL DEFAULT 0,
  prize_2 integer NOT NULL DEFAULT 0,
  prize_3 integer NOT NULL DEFAULT 0,
  prize_4 integer NOT NULL DEFAULT 0,
  prize_5 integer NOT NULL DEFAULT 0,
  scheduled_at timestamptz NOT NULL,
  status public.match_status NOT NULL DEFAULT 'upcoming',
  room_id_text text,
  room_password text,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authed view matches" ON public.matches FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin creates matches" ON public.matches FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "Admin updates matches" ON public.matches FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admin deletes matches" ON public.matches FOR DELETE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_matches_updated BEFORE UPDATE ON public.matches FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
ALTER TABLE public.matches REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.matches;

CREATE TABLE public.match_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES public.matches(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  rank integer,
  prize_coins integer NOT NULL DEFAULT 0,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (match_id, user_id)
);
ALTER TABLE public.match_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authed view entries" ON public.match_entries FOR SELECT TO authenticated USING (true);
CREATE POLICY "Self joins match" ON public.match_entries FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE POLICY "Admin updates entries" ON public.match_entries FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Self or admin removes entry" ON public.match_entries FOR DELETE TO authenticated USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE INDEX idx_entry_match ON public.match_entries(match_id);
CREATE INDEX idx_entry_user ON public.match_entries(user_id);
ALTER TABLE public.match_entries REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.match_entries;

CREATE OR REPLACE FUNCTION public.handle_new_user_wallet()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.wallets (user_id, coins, diamonds) VALUES (NEW.id, 100, 0) ON CONFLICT (user_id) DO NOTHING;
  INSERT INTO public.wallet_transactions (user_id, kind, coins_delta, note) VALUES (NEW.id, 'signup_bonus', 100, 'Welcome bonus');
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS on_auth_user_wallet ON auth.users;
CREATE TRIGGER on_auth_user_wallet AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_wallet();

CREATE OR REPLACE FUNCTION public.join_match(_match_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _m record; _count int; _bal int;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT * INTO _m FROM public.matches WHERE id = _match_id FOR UPDATE;
  IF _m IS NULL THEN RAISE EXCEPTION 'Match not found'; END IF;
  IF _m.status <> 'upcoming' THEN RAISE EXCEPTION 'Match not open'; END IF;
  SELECT COUNT(*) INTO _count FROM public.match_entries WHERE match_id = _match_id;
  IF _count >= _m.max_players THEN RAISE EXCEPTION 'Match full'; END IF;
  IF EXISTS (SELECT 1 FROM public.match_entries WHERE match_id = _match_id AND user_id = _uid) THEN RAISE EXCEPTION 'Already joined'; END IF;
  SELECT coins INTO _bal FROM public.wallets WHERE user_id = _uid FOR UPDATE;
  IF _bal IS NULL THEN INSERT INTO public.wallets(user_id, coins) VALUES (_uid, 0); _bal := 0; END IF;
  IF _bal < _m.entry_fee THEN RAISE EXCEPTION 'Insufficient coins'; END IF;
  UPDATE public.wallets SET coins = coins - _m.entry_fee WHERE user_id = _uid;
  INSERT INTO public.wallet_transactions(user_id, kind, coins_delta, match_id, note) VALUES (_uid,'entry_fee',-_m.entry_fee,_match_id,'Match entry: '||_m.title);
  INSERT INTO public.match_entries(match_id, user_id) VALUES (_match_id, _uid);
  RETURN jsonb_build_object('ok', true, 'remaining_coins', _bal - _m.entry_fee);
END $$;

CREATE OR REPLACE FUNCTION public.set_match_ranks(_match_id uuid, _ranks jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _m record; _item jsonb; _uid uuid; _rank int; _prize int;
BEGIN
  IF NOT has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  SELECT * INTO _m FROM public.matches WHERE id = _match_id FOR UPDATE;
  IF _m IS NULL THEN RAISE EXCEPTION 'Match not found'; END IF;
  FOR _item IN SELECT * FROM jsonb_array_elements(_ranks) LOOP
    _uid := (_item->>'user_id')::uuid;
    _rank := (_item->>'rank')::int;
    _prize := CASE _rank WHEN 1 THEN _m.prize_1 WHEN 2 THEN _m.prize_2 WHEN 3 THEN _m.prize_3 WHEN 4 THEN _m.prize_4 WHEN 5 THEN _m.prize_5 ELSE 0 END;
    UPDATE public.match_entries SET rank = _rank, prize_coins = _prize WHERE match_id = _match_id AND user_id = _uid;
    IF _prize > 0 THEN
      INSERT INTO public.wallets(user_id, coins) VALUES (_uid, _prize) ON CONFLICT (user_id) DO UPDATE SET coins = wallets.coins + _prize;
      INSERT INTO public.wallet_transactions(user_id, kind, coins_delta, match_id, note) VALUES (_uid,'prize',_prize,_match_id,'Rank #'||_rank||' — '||_m.title);
    END IF;
  END LOOP;
  UPDATE public.matches SET status = 'completed' WHERE id = _match_id;
  RETURN jsonb_build_object('ok', true);
END $$;

CREATE OR REPLACE FUNCTION public.exchange_coins(_packs int)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _coins_needed int; _diamonds_gained int; _bal int;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _packs < 1 THEN RAISE EXCEPTION 'Invalid pack count'; END IF;
  _coins_needed := _packs * 1500; _diamonds_gained := _packs * 100;
  SELECT coins INTO _bal FROM public.wallets WHERE user_id = _uid FOR UPDATE;
  IF _bal IS NULL OR _bal < _coins_needed THEN RAISE EXCEPTION 'Insufficient coins'; END IF;
  UPDATE public.wallets SET coins = coins - _coins_needed, diamonds = diamonds + _diamonds_gained WHERE user_id = _uid;
  INSERT INTO public.wallet_transactions(user_id, kind, coins_delta, diamonds_delta, note) VALUES (_uid,'exchange_coins_out',-_coins_needed,_diamonds_gained,'Exchanged '||_packs||' pack(s)');
  RETURN jsonb_build_object('ok', true);
END $$;

INSERT INTO public.wallets (user_id, coins, diamonds) SELECT id, 100, 0 FROM auth.users ON CONFLICT (user_id) DO NOTHING;
