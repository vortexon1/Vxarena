-- 1. profiles updates
ALTER TABLE public.profiles ALTER COLUMN phone DROP NOT NULL;

DO $$ BEGIN
  CREATE TYPE public.player_region AS ENUM ('Pakistan','India','Bangladesh','Indonesia','Nepal','Brazil','Others');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS region public.player_region,
  ADD COLUMN IF NOT EXISTS ff_screenshot_url text,
  ADD COLUMN IF NOT EXISTS profile_completed boolean NOT NULL DEFAULT false;

ALTER TABLE public.profiles DROP COLUMN IF EXISTS reputation;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS warning_count;

-- 2. Drop ratings system (CASCADE removes trigger + function deps)
DROP TABLE IF EXISTS public.ratings CASCADE;
DROP FUNCTION IF EXISTS public.recalc_reputation() CASCADE;
DROP TYPE IF EXISTS public.rating_value;

-- 3. Rooms
CREATE TABLE IF NOT EXISTS public.rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  owner_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.room_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_id, user_id)
);
CREATE TABLE IF NOT EXISTS public.room_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_messages ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_room_member(_room uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT EXISTS (SELECT 1 FROM public.room_members WHERE room_id = _room AND user_id = _user)
$$;

CREATE POLICY "Members can view their rooms" ON public.rooms FOR SELECT TO authenticated
  USING (owner_id = auth.uid() OR public.is_room_member(id, auth.uid()));
CREATE POLICY "Users can create rooms" ON public.rooms FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Owner can update room" ON public.rooms FOR UPDATE TO authenticated
  USING (owner_id = auth.uid());
CREATE POLICY "Owner can delete room" ON public.rooms FOR DELETE TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "Members view membership" ON public.room_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_room_member(room_id, auth.uid()));
CREATE POLICY "Owner or self can add members" ON public.room_members FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.rooms r WHERE r.id = room_id AND r.owner_id = auth.uid())
    OR user_id = auth.uid()
  );
CREATE POLICY "Members can leave or owner can remove" ON public.room_members FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR EXISTS (SELECT 1 FROM public.rooms r WHERE r.id = room_id AND r.owner_id = auth.uid()));

CREATE POLICY "Members view messages" ON public.room_messages FOR SELECT TO authenticated
  USING (public.is_room_member(room_id, auth.uid()));
CREATE POLICY "Members send messages" ON public.room_messages FOR INSERT TO authenticated
  WITH CHECK (sender_id = auth.uid() AND public.is_room_member(room_id, auth.uid()));

ALTER PUBLICATION supabase_realtime ADD TABLE public.room_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.room_members;

-- 4. Storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('ff-screenshots', 'ff-screenshots', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "FF screenshots are public" ON storage.objects FOR SELECT
  USING (bucket_id = 'ff-screenshots');
CREATE POLICY "Users can upload own FF screenshot" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'ff-screenshots' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update own FF screenshot" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'ff-screenshots' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can delete own FF screenshot" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'ff-screenshots' AND auth.uid()::text = (storage.foldername(name))[1]);