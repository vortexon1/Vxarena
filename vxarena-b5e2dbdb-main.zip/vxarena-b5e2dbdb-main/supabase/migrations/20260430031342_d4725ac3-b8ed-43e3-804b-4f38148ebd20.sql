-- Triggers are invoked by the table owner; ensure postgres/supabase roles can execute
GRANT EXECUTE ON FUNCTION public.handle_admin_email() TO postgres, service_role, supabase_auth_admin;
GRANT EXECUTE ON FUNCTION public.handle_new_user_role() TO postgres, service_role, supabase_auth_admin;
GRANT EXECUTE ON FUNCTION public.touch_updated_at() TO postgres, service_role, supabase_auth_admin;